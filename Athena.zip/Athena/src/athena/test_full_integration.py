import sys, os
sys.path.insert(0, os.path.abspath("src"))

from datetime import datetime
from athena.memory.core.factory import MemoryFactory
from athena.memory.core.dtos import (
    MemoryRecord, 
    MemoryQuery, 
    MemoryDomain, 
    MemoryPolicy, 
    PrivacyLevel
)
from athena.memory.core.events import MemoryEvent, MemoryEventType


class AthenaKernelSimulation:
    """Simulação do Kernel Cognitivo conectando o Executive, Agentes e o MOS."""

    def __init__(self):
        print(" [BOOT KERNEL] Inicializando o Athena Cognitive Operating System (COS)...")
        # 1. Boot do MOS via Factory (Com recuperação automática do disco)
        self.mos = MemoryFactory.create_manager()
        
        # 2. Conecta auditoria de eventos do Kernel
        self.mos.event_bus.subscribe(MemoryEventType.CREATED, self._on_memory_created)

    def _on_memory_created(self, event: MemoryEvent):
        print(f"   📢 [EVENT BUS -> KERNEL] Nova memória registrada! ID: {event.entry_id} | Domínio: {event.payload.get('domain')}")

    def execute_mission(self, user_prompt: str, domain: MemoryDomain):
        print("\n" + "─" * 60)
        print(f" 🚀 [EXECUTIVE] Nova Missão Recebida: '{user_prompt}'")
        print("─" * 60)

        # PASSO 1: O Executive consulta o MOS para resgatar contexto anterior
        print("\n 🔍 1. Executive consultando o MOS por conhecimentos prévios...")
        query = MemoryQuery(query_text=user_prompt.split()[0], domain=domain)
        contexto_previo = self.mos.search(query)

        if contexto_previo:
            print(f"    └─ [CONTEXTO RESGATADO] {len(contexto_previo)} registros antigos encontrados para enriquecer o prompt!")
            for idx, item in enumerate(contexto_previo, 1):
                print(f"       [{idx}] {item.content[:50]}...")
        else:
            print("    └─ [CONTEXTO] Nenhum registro prévio sobre o tema. Iniciando do zero.")

        # PASSO 2: O Agente Especialista gera a resposta (Simulado)
        print("\n 🧠 2. Despachando missão para o Agente Especialista...")
        resposta_agente = (
            f"Análise Jurídica concluída para: '{user_prompt}'. "
            f"Com base na legislação vigente, os direitos fundamentais garantem a presunção de inocência."
        )
        print(f"    └─ [RESPOSTA DO AGENTE]: {resposta_agente}")

        # PASSO 3: Gravação do resultado no MOS (Persistência no Disco)
        print("\n 💾 3. Gravando a resposta consolidada da missão no MOS...")
        registro = MemoryRecord(
            content=resposta_agente,
            domain=domain,
            metadata={"origem": "ExecutiveCore", "missao": user_prompt, "timestamp": str(datetime.now())},
            policy=MemoryPolicy(privacy=PrivacyLevel.INTERNAL, confidence_score=0.92)
        )
        
        entry = self.mos.save(registro)
        print(f"    └─ [SISTEMA] Missão gravada com êxito em disco no ID: {entry.id}")


def main():
    print("\n" + "=" * 70)
    print("      🏛️  ATHENA COS - TESTE DE INTEGRAÇÃO DO SISTEMA COMPLETO  🏛️")
    print("=" * 70)

    # Boot do Kernel com MOS integrado
    kernel = AthenaKernelSimulation()

    # Execução da Primeira Missão
    kernel.execute_mission(
        user_prompt="Quais são os limites da busca e apreensão domiciliar?",
        domain=MemoryDomain.LEGAL
    )

    # Execução de uma Segunda Missão no mesmo domínio
    kernel.execute_mission(
        user_prompt="Explique os limites e garantias da CF",
        domain=MemoryDomain.LEGAL
    )

    print("\n" + "=" * 70)
    print("      ✅ TESTE DE INTEGRAÇÃO DO SISTEMA COMPLETO CONCLUÍDO!")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    main()