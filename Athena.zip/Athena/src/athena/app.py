import sys, os
sys.path.insert(0, os.path.abspath("src"))

from athena.core.bootstrap.kernel_bootstrap import KernelBootstrap
from athena.domain.task import Task, TaskType

def main():
    print("\n" + "=" * 60)
    print("          🏛️  ATHENA COGNITIVE SYSTEM v1.0  🏛️")
    print("=" * 60)
    print(" [INFO] Inicializando Kernel da Athena...")

    # Instancia todo o sistema via fábrica central (KernelBootstrap)
    controller = KernelBootstrap.build()

    print(" [OK]   Fluxo Loader -> Registry -> Router -> Core montado com sucesso!")
    print(" [INFO] Digite sua ordem/missão para o Kernel (ou 'sair' para encerrar).\n")

    task_count = 1

    while True:
        try:
            user_input = input("\nPaulo > ").strip()

            if not user_input:
                continue

            if user_input.lower() in ["sair", "exit", "quit"]:
                print("\nEncerrando sessão do Kernel Athena. Até logo!\n")
                break

            task = Task(
                id=f"task_user_{task_count:03d}",
                title=f"Atendimento Interativo #{task_count}",
                description=user_input,
                task_type=TaskType.RESEARCH
            )

            print("\n" + "-" * 50)
            print(f" [ATHENA] Processando Ordem de Missão: '{user_input}'")
            print("-" * 50)

            context = controller.submit(task)
            task_count += 1

        except KeyboardInterrupt:
            print("\n\nSessão interrompida pelo usuário.")
            break
        except Exception as e:
            print(f"\n❌ Erro durante o processamento da missão: {e}")

if __name__ == "__main__":
    main()