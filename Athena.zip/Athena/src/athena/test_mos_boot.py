import sys, os
sys.path.insert(0, os.path.abspath("src"))

from athena.memory.core.factory import MemoryFactory
from athena.memory.core.dtos import MemoryRecord, MemoryQuery, MemoryDomain, MemoryPolicy, PrivacyLevel


def main():
    print("\n" + "=" * 75)
    print("      🏛️  ATHENA MOS v2.2 - TESTE DE SOBREVIVÊNCIA AO RESTART  🏛️")
    print("=" * 75)

    # -------------------------------------------------------------------
    # ETAPA 1: SESSÃO A (Grava dados e desliga o processo)
    # -------------------------------------------------------------------
    print("\n [SESSÃO A] Inicializando Athena MOS pela primeira vez...")
    mos_sessao_a = MemoryFactory.create_manager()

    rec_1 = MemoryRecord(
        content="Art. 5º, LVII da CF - Ninguém será considerado culpado até o trânsito em julgado.",
        domain=MemoryDomain.LEGAL,
        metadata={"origem": "Sessão A"},
        policy=MemoryPolicy(privacy=PrivacyLevel.INTERNAL, confidence_score=0.98)
    )

    entry_a = mos_sessao_a.save(rec_1)
    print(f" [SESSÃO A] Dado salvo no disco com ID: {entry_a.id}")

    # Simula o encerramento do processo (Limpando a memória RAM)
    print("\n [ENCERRANDO SISTEMA] Fechando o VS Code / Matando o processo Python...")
    del mos_sessao_a

    # -------------------------------------------------------------------
    # ETAPA 2: SESSÃO B (Reboot limpo - "Cold Start")
    # -------------------------------------------------------------------
    print("\n " + "-" * 65)
    print(" [SESSÃO B - REBOOT] Ligando o computador e iniciando uma NOVA instância...")
    print(" " + "-" * 65)

    mos_sessao_b = MemoryFactory.create_manager()

    # Tenta buscar o dado gravado na Sessão A sem ter rodado save() nesta sessão
    print("\n [TESTE DE AMNÉSIA] Buscando artigo constitucional salvo na Sessão A...")
    query = MemoryQuery(query_text="trânsito em julgado", domain=MemoryDomain.LEGAL)
    resultados = mos_sessao_b.search(query)

    print(f"\n [RESULTADO DO TESTE DE REBOOT]:")
    if len(resultados) > 0:
        for res in resultados:
            print(f"  🟢 SUCESSO ABSOLUTO! Memória resgatada do disco pós-restart:")
            print(f"     └─ ID: {res.id}")
            print(f"     └─ Conteúdo: {res.content}")
            print(f"     └─ Metadata: {res.metadata}")
    else:
        print("  🔴 FALHA: Amnésia pós-restart detectada. Nenhum registro encontrado.")

    print("\n" + "=" * 75)
    print("      ✅ O ÍNDICE AGORA RECONSTRÓI PERFEITAMENTE NO BOOT!")
    print("=" * 75 + "\n")


if __name__ == "__main__":
    main()