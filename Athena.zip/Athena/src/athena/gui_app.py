import sys
import os
import traceback
import tkinter as tk
from tkinter import scrolledtext
from threading import Thread

# Ajuste de caminhos para importação dos módulos da Athena
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SRC_DIR = os.path.join(BASE_DIR, "src")
if os.path.exists(SRC_DIR) and SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)
elif os.path.abspath("src") not in sys.path:
    sys.path.insert(0, os.path.abspath("src"))

from athena.core.microkernel import MicroKernel
from athena.core.llm_adapter import MockLLMAdapter, AnthropicAdapter
from athena.agents_ofc.tech_driver import TechDriver
from athena.agents_ofc.specialist_drivers import (
    JustitiaDriver,
    SophiaDriver,
    LogosDriver,
    MusaDriver,
    StrategosDriver,
    MnemosyneDriver,
    CritiasDriver,
)
from athena.core.orchestrator import DecisionEngineV1, MissionOrchestrator


def get_default_llm_adapter():
    """Centraliza a decisão do LLM: usa Anthropic se a chave/modo existir, ou Mock como fallback."""
    mode = os.environ.get("ATHENA_LLM_MODE", "mock").lower()
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    model_name = os.environ.get("ATHENA_LLM_MODEL", "claude-3-5-sonnet-latest")
    if mode == "mock":
        return MockLLMAdapter()

    if api_key and mode in ("auto", "real", "anthropic"):
        try:
            return AnthropicAdapter(model=model_name, api_key=api_key, timeout=30.0)
        except Exception as e:
            print(f"⚠️ Falha ao inicializar AnthropicAdapter ({e}). Usando MockLLMAdapter.")
            return MockLLMAdapter()

    return MockLLMAdapter()


class AthenaGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("🏛️ Athena Cognitive System")
        self.root.geometry("900x700")
        self.root.configure(bg="#121212")

        # Boot da Arquitetura Agêntica Reativa
        self._bootstrap_new_kernel()
        self._build_ui()

    def _bootstrap_new_kernel(self):
        """Inicializa o Microkernel, o LLM Adapter centralizado e os 8 Specialist Drivers."""
        self.llm = get_default_llm_adapter()
        self.kernel = MicroKernel()

        drivers = [
            TechDriver(self.llm),
            JustitiaDriver(self.llm),
            SophiaDriver(self.llm),
            LogosDriver(self.llm),
            MusaDriver(self.llm),
            StrategosDriver(self.llm),
            MnemosyneDriver(self.llm),
            CritiasDriver(self.llm),
        ]

        for d in drivers:
            self.kernel.plugin_manager.load_plugin(d)

        self.decision_engine = DecisionEngineV1()
        self.orchestrator = MissionOrchestrator(self.kernel, self.decision_engine)

    def _build_ui(self):
        # Header
        header_frame = tk.Frame(self.root, bg="#1E1E1E", height=60)
        header_frame.pack(fill="x", side="top")

        title_label = tk.Label(
            header_frame,
            text="🏛️ ATHENA COGNITIVE KERNEL",
            font=("Consolas", 14, "bold"),
            fg="#00E676",
            bg="#1E1E1E"
        )
        title_label.pack(side="left", padx=20, pady=15)

        llm_type_str = "REAL (ANTHROPIC)" if isinstance(self.llm, AnthropicAdapter) else "MOCK (OFFLINE)"
        self.status_label = tk.Label(
            header_frame,
            text=f"● KERNEL ONLINE [{llm_type_str}]",
            font=("Consolas", 10, "bold"),
            fg="#00E676" if "REAL" in llm_type_str else "#00B0FF",
            bg="#1E1E1E"
        )
        self.status_label.pack(side="right", padx=20)

        # Chat Area
        self.chat_area = scrolledtext.ScrolledText(
            self.root,
            wrap=tk.WORD,
            font=("Consolas", 10),
            bg="#1A1A1A",
            fg="#E0E0E0",
            insertbackground="white",
            relief="flat",
            bd=0
        )
        self.chat_area.pack(fill="both", expand=True, padx=15, pady=15)

        self.chat_area.tag_config("user", foreground="#00B0FF", font=("Consolas", 10, "bold"))
        self.chat_area.tag_config("athena", foreground="#00E676", font=("Consolas", 10, "bold"))
        self.chat_area.tag_config("response", foreground="#FFFFFF", font=("Consolas", 10))
        self.chat_area.tag_config("reactive", foreground="#FFD700", font=("Consolas", 10, "bold"))
        self.chat_area.tag_config("system", foreground="#888888")
        self.chat_area.tag_config("error", foreground="#FF5252", font=("Consolas", 10, "bold"))

        self._append_chat("SISTEMA", f"MicroKernel reativo da Athena inicializado [{llm_type_str}]. Digite sua missão abaixo.\n", "system")

        # Input Area
        input_frame = tk.Frame(self.root, bg="#121212")
        input_frame.pack(fill="x", side="bottom", padx=15, pady=15)

        self.entry = tk.Entry(
            input_frame,
            font=("Consolas", 11),
            bg="#252526",
            fg="#FFFFFF",
            insertbackground="white",
            relief="flat",
            bd=5
        )
        self.entry.pack(side="left", fill="x", expand=True, ipady=8, padx=(0, 10))
        self.entry.bind("<Return>", lambda event: self.send_message())

        self.send_btn = tk.Button(
            input_frame,
            text="ENVIAR",
            font=("Consolas", 10, "bold"),
            bg="#00E676",
            fg="#000000",
            activebackground="#00C853",
            relief="flat",
            cursor="hand2",
            command=self.send_message
        )
        self.send_btn.pack(side="right", ipadx=15, ipady=5)

    def _append_chat(self, sender: str, text: str, tag: str):
        def update_ui():
            self.chat_area.config(state="normal")
            if sender:
                self.chat_area.insert(tk.END, f"\n[{sender}]: ", tag)
            self.chat_area.insert(tk.END, f"{text}\n", tag)
            self.chat_area.config(state="disabled")
            self.chat_area.yview(tk.END)

        self.root.after(0, update_ui)

    def _set_input_state(self, enabled: bool):
        """Bloqueia a entrada durante a execução para evitar chamadas concorrentes."""
        def update_state():
            state = "normal" if enabled else "disabled"
            btn_bg = "#00E676" if enabled else "#555555"
            self.entry.config(state=state)
            self.send_btn.config(state=state, bg=btn_bg)
        self.root.after(0, update_state)

    def send_message(self):
        user_text = self.entry.get().strip()
        if not user_text:
            return

        self.entry.delete(0, tk.END)
        self._append_chat("PAULO", user_text, "user")

        # Bloqueia a GUI contra envios duplicados em paralelo
        self._set_input_state(False)

        Thread(target=self._process_mission, args=(user_text,), daemon=True).start()

    def _process_mission(self, user_text: str):
        try:
            self._append_chat("ATHENA", "Orquestrando missão via DecisionEngineV1...", "athena")

            res = self.orchestrator.run_mission(user_text)

            # Inspecção do Estado Final do Mission Log
            final_status = res.get("final_state", {}).get("status", "COMPLETED")

            if final_status == "FAILED":
                # Extração cirúrgica da causa raiz no Log imutável
                fail_reason = "Limite de replanejamento atingido ou falha desconhecida no provedor."
                for evt in reversed(res.get("log_history", [])):
                    if evt.event_type in ("DriverExecutionFailed", "MissionFailed"):
                        payload = evt.payload or {}
                        fail_reason = (
                            payload.get("error") or
                            payload.get("reason") or
                            payload.get("message") or
                            str(payload)
                        )
                        break

                self._append_chat(
                    "SISTEMA",
                    f"⚠️ FALHA NA MISSÃO:\n{fail_reason}",
                    "error"
                )
            else:
                output_text = res.get("output", "Missão concluída sem saída de texto.")
                self._append_chat("ATHENA", output_text, "response")

                # Destaque de reatividade capturada no Mission Log
                for evt in res.get("log_history", []):
                    if evt.event_type == "ComplianceAuditInitiated":
                        reactive_msg = (
                            f"🔔 [EVENTO REATIVO COMPLIANCE - JUSTITIA]:\n"
                            f"{evt.payload.get('answer')}"
                        )
                        self._append_chat("SISTEMA", reactive_msg, "reactive")

        except Exception as err:
            error_msg = f"❌ Erro Crítico no MicroKernel: {str(err)}\n{traceback.format_exc()}"
            print(error_msg)
            self._append_chat("ERRO", f"Falha ao processar: {str(err)}", "error")
        finally:
            # Libera a GUI para a próxima missão
            self._set_input_state(True)


def main():
    root = tk.Tk()
    app = AthenaGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()