from athena.agents_ofc.base_agent import Specialist
from athena.domain.capability import Capability
from athena.domain.cognitve_process import CognitiveProcess

class EchoAgent(Specialist):
    """Especialista de testes (Mock)."""
    capability = Capability.LOGIC
    is_mock = True  # Flag de segurança para o Loader
    processes = [
        CognitiveProcess.RESEARCH,
        CognitiveProcess.ANALYSIS,
        CognitiveProcess.ARGUMENTATION,
        CognitiveProcess.VALIDATION,
        CognitiveProcess.SYNTHESIS,
    ]

    def run(self, context: dict) -> dict:
        step_name = context.get("step_name", "Etapa Desconhecida")
        return {
            "status": "success",
            "agent": "EchoAgent",
            "output": f"[ECHO OK] Processamento da etapa '{step_name}' executado."
        }