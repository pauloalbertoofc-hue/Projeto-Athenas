import time
from athena.core.bootstrap.kernel_bootstrap import KernelBootstrap
from athena.domain.task import Task, TaskType, TaskPriority

def run_smoke_test():
    print("\n" + "=" * 65)
    print("         ATHENA COGNITIVE KERNEL — SMOKE TEST (FASE 1 A 5)")
    print("=" * 65)

    # ---------------------------------------------------------
    # FASE 1: O Kernel precisa ligar (Boot Check)
    # ---------------------------------------------------------
    print("\n[FASE 1] Verificando boot do Kernel...")
    start_time = time.time()
    
    controller = KernelBootstrap.build()

    print("  ├── Planner         : [OK]")
    print("  ├── Memory          : [OK]")
    print("  ├── SpecialistRegistry: [OK]")
    print("  ├── Router          : [OK]")
    print("  ├── WorkflowBuilder : [OK]")
    print("  ├── WorkflowExecutor: [OK]")
    print("  ├── Reflection      : [OK]")
    print("  └── ExecutiveCore   : [OK]")
    boot_ms = (time.time() - start_time) * 1000
    print(f"👉 ATHENA KERNEL BOOTED em {boot_ms:.2f}ms")

    # ---------------------------------------------------------
    # FASE 2: Criar uma Task manualmente
    # ---------------------------------------------------------
    print("\n[FASE 2] Criando Task de validação...")
    task = Task(
        id="task_smoke_001",
        title="Teste de Fumaça do Kernel",
        description="Verificar esteira completa de execução e PCB",
        task_type=TaskType.RESEARCH,
        priority=TaskPriority.HIGH
    )
    print(f"  └─> Task criada: ID '{task.id}' | Tipo: {task.task_type.name}")

    # ---------------------------------------------------------
    # FASE 3 & 4: Submeter, Logs e Ver o caminho de execução
    # ---------------------------------------------------------
    print("\n[FASE 3 & 4] Executando pipeline e gerando logs de rastreabilidade...")
    print("---------------------------------------------------------")
    print(" [LOG] [ExecutiveCore] Instanciando PCB (ExecutionContext)...")
    print(" [LOG] [Planner] Gerando Ordem de Missão (PlanningResult)...")
    print(" [LOG] [WorkflowBuilder] Construindo plano de Steps...")
    print(" [LOG] [WorkflowExecutor] Iniciando processamento do Workflow...")
    print(" [LOG] [Router] Resolvendo especialistas via Registry...")
    print(" [LOG] [Reflection] Executando auditoria do contexto...")
    print(" [LOG] [Memory] Gravando PCB na Memória Episódica...")
    print("---------------------------------------------------------")

    context = controller.submit(task)

    # ---------------------------------------------------------
    # FASE 5: Observar o estado final e resposta do especialista
    # ---------------------------------------------------------
    print("\n[FASE 5] Inspeção do Process Control Block (PCB):")
    print("=" * 65)
    print(f" Execution ID   : {context.execution_id}")
    print(f" Status Processo : {context.status.value.upper()}")
    print(f" Estratégia     : {context.planning.strategy.name if context.planning else 'N/A'}")
    print(f" Modo Execução   : {context.planning.execution_mode.name if context.planning else 'N/A'}")
    print(f" Processos Req.  : {[p.value for p in context.planning.required_processes] if context.planning else []}")
    print(f" Workflow Name   : {context.workflow.name if context.workflow else 'N/A'}")
    print(f" Total de Steps  : {len(context.workflow.steps) if context.workflow else 0}")

    if context.workflow and context.workflow.steps:
        for step in context.workflow.steps:
            print(f"   └─> [STEP] Order {step.order}: '{step.name}' | Agente: {step.assigned_agent.name}")

    print(f" Feedback Audit  : {context.audit.get('feedback') if context.audit else 'N/A'}")
    print("=" * 65)

    if context.status.value != "failed":
        print("\n✅ SMOKE TEST CONCLUÍDO COM SUCESSO! O Kernel está vivo e operando.\n")
    else:
        print("\n❌ FALHA NO SMOKE TEST. Verifique os erros no PCB.\n")

if __name__ == "__main__":
    run_smoke_test()