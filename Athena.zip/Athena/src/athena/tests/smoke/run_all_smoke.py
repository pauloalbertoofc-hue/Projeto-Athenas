import os
import subprocess
import sys

# Caminhos diretos dos testes a partir da raiz do projeto
SMOKE_TESTS = [
    "src/athena/tests/smoke/smoke_boot.py",
    "src/athena/tests/smoke/smoke_end_to_end.py",
]

def run_all():
    print("==================================================")
    print("       ATHENA KERNEL — SUÍTE DE TESTES DE FUMAÇA   ")
    print("==================================================\n")

    # Injeta a pasta 'src' no PYTHONPATH dos subprocessos
    env = os.environ.copy()
    env["PYTHONPATH"] = os.path.abspath("src")

    failed = False
    for test in SMOKE_TESTS:
        result = subprocess.run([sys.executable, test], env=env)
        if result.returncode != 0:
            failed = True
            print(f"\n❌ Abortando: O teste '{test}' falhou.\n")
            break

    if not failed:
        print("\n==================================================")
        print("   🎉 TODOS OS TESTES DE FUMAÇA PASSARAM COM ÊXITO! ")
        print("==================================================\n")

if __name__ == "__main__":
    run_all()