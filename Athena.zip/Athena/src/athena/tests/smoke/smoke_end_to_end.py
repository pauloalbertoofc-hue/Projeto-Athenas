import sys, os
sys.path.insert(0, os.path.abspath("src"))

from athena.core.bootstrap.kernel_bootstrap import KernelBootstrap
from athena.domain.task import Task, TaskType

def test_end_to_end_pipeline():
    print("\nRunning Smoke Test: End-to-End Pipeline com EchoAgent...")

    controller = KernelBootstrap.build()

    task = Task(
        id="task_smoke_001",
        title="Validação com Mock Specialist",
        description="Teste automatizado de execução com EchoAgent",
        task_type=TaskType.RESEARCH
    )

    context = controller.submit(task)

    # Diagnóstico: se o workflow for None, imprime os detalhes do contexto
    if context.workflow is None:
        print("\n🔍 DIAGNÓSTICO DE ERRO NO EXECUTIONCONTEXT:")
        print(f"  ├── Status do Processo : {getattr(context, 'status', 'N/A')}")
        print(f"  ├── Metadata / Erros   : {getattr(context, 'metadata', 'N/A')}")
        print(f"  └── Audit              : {getattr(context, 'audit', 'N/A')}\n")

    try:
        assert context is not None, "O ExecutionContext (PCB) retornado é nulo."
        assert context.workflow is not None, "Workflow não foi gerado dentro do contexto."
        assert len(context.workflow.steps) > 0, "Nenhum Step foi adicionado ao Workflow."

        print("✅ [PIPELINE OK] O EchoAgent respondeu aos Steps e o Kernel finalizou com sucesso!")

    except AssertionError as ae:
        print(f"❌ [SMOKE TEST FAILED] {ae}")
        sys.exit(1)

if __name__ == "__main__":
    test_end_to_end_pipeline()