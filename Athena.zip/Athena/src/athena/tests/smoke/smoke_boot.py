import sys
from athena.core.bootstrap.kernel_bootstrap import KernelBootstrap

def test_kernel_boot():
    print("Running Smoke Test: Kernel Boot...")
    try:
        controller = KernelBootstrap.build()
        assert controller is not None, "ExecutiveController não pode ser Nulo."
        print("✅ [BOOT OK] Kernel inicializado sem exceções.")
    except Exception as e:
        print(f"❌ [BOOT FAILED] Falha ao inicializar o Kernel: {e}")
        sys.exit(1)

if __name__ == "__main__":
    test_kernel_boot()