import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from athena.core.microkernel import MicroKernel
from athena.core.llm_adapter import AnthropicAdapter
from athena.agents_ofc.tech_driver import TechDriver
from athena.agents_ofc.specialist_drivers import (
    JustitiaDriver,
    SophiaDriver,
    LogosDriver,
    MusaDriver,
    StrategosDriver,
    MnemosyneDriver,
    CritiasDriver,
)
from athena.core.orchestrator import DecisionEngineV1, MissionOrchestrator


def setup_kernel_with_llm(llm_adapter) -> MicroKernel:
    kernel = MicroKernel()
    drivers = [
        TechDriver(llm_adapter),
        JustitiaDriver(llm_adapter),
        SophiaDriver(llm_adapter),
        LogosDriver(llm_adapter),
        MusaDriver(llm_adapter),
        StrategosDriver(llm_adapter),
        MnemosyneDriver(llm_adapter),
        CritiasDriver(llm_adapter),
    ]

    for d in drivers:
        kernel.plugin_manager.load_plugin(d)

    return kernel


def main():
    print("\n" + "=" * 75)
    print("      🏛️ ATHENA COS — TESTE DE PRODUÇÃO COM LLM REAL (ANTHROPIC) 🏛️")
    print("=" * 75 + "\n")

    # Verifica se a chave de API está presente no ambiente
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("❌ ERROR: A variável de ambiente ANTHROPIC_API_KEY não foi encontrada!")
        print("Execute no terminal: $env:ANTHROPIC_API_KEY=\"sua-chave\" antes de rodar.")
        return

    # Instancia o adapter da Anthropic com o modelo Sonnet 3.5 e timeout de 30s
    llm = AnthropicAdapter(model="claude-3-5-sonnet-20241022", api_key=api_key, timeout=30.0)
    kernel = setup_kernel_with_llm(llm)

    decision_engine = DecisionEngineV1()
    orchestrator = MissionOrchestrator(kernel, decision_engine)

    # Execução de missão reativa real
    prompt_missao = "Analisar o código Python de uma API de pagamentos e verificar vulnerabilidades de segurança e conformidade legal"
    print(f" 🚀 Executando Missão Real:\n    '{prompt_missao}'\n")
    print(" ⏳ Aguardando processamento das mentes cognitivas na API...\n")

    res = orchestrator.run_mission(prompt_missao)

    print("\n" + "=" * 75)
    print(" 📌 SAÍDA FINAL DA MISSÃO (TEXTO GERADO PELO CLAUDE REAL):")
    print("=" * 75)
    print(res["output"])

    print("\n" + "=" * 75)
    print(" 🔍 AUDITORIA DO MISSION LOG (Cadeia Reativa Auditada):")
    print("=" * 75)
    for idx, evt in enumerate(res["log_history"], 1):
        print(f"    [{idx:02d}] EventType: {evt.event_type:<24} | Agent: {evt.agent:<16} | Slot: {evt.slot}")
        if evt.event_type == "ComplianceAuditInitiated":
            print(f"\n      🔔 PARECER REATIVO DA JUSTITIA (LLM REAL):\n{evt.payload.get('answer')}\n")

    print("\n" + "=" * 75)
    print("      ✅ VALIDAÇÃO COGNITIVA EM PRODUÇÃO CONCLUÍDA COM SUCESSO!")
    print("=" * 75 + "\n")


if __name__ == "__main__":
    main()