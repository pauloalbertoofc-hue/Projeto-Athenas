from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Any
from uuid import uuid4
from athena.domain.step import Step, StepStatus

class WorkflowStatus(Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    COMPLETED = "completed"
    FAILED = "failed"

@dataclass
class Workflow:
    """
    Representa o motor de raciocínio da Athena.
    Gerencia o plano de execução composto por múltiplos passos ordenados (Steps).
    """
    name: str
    description: str
    id: str = field(default_factory=lambda: str(uuid4()), repr=False)
    status: WorkflowStatus = WorkflowStatus.DRAFT
    steps: List[Step] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict, repr=False)
    created_at: datetime = field(default_factory=datetime.utcnow, repr=False)
    updated_at: datetime = field(default_factory=datetime.utcnow, repr=False)

    def add_step(self, step: Step):
        """Adiciona uma etapa de raciocínio estruturada ao plano e ordena a lista."""
        self.steps.append(step)
        self.steps.sort(key=lambda s: s.order)
        self.updated_at = datetime.utcnow()

    def next_executable_step(self) -> Step | None:
        """
        Determina qual o próximo passo na fila pronto para ser executado.
        No futuro, validará dependências, tokens e concorrência.
        """
        for step in self.steps:
            if step.status == StepStatus.PENDING:
                return step
        return None

    @property
    def is_complete(self) -> bool:
        """Retorna verdadeiro se todos os passos foram executados com sucesso."""
        if not self.steps:
            return False
        return all(step.status == StepStatus.COMPLETED for step in self.steps)

    @property
    def has_failed_step(self) -> bool:
        """Detecta se alguma parte do raciocínio falhou em cadeia."""
        return any(step.status == StepStatus.FAILED for step in self.steps)

    def __str__(self):
        return f"Workflow('{self.name}', steps={len(self.steps)}, status={self.status.value})"