from typing import Any, Dict, Optional

class WorkingMemory:
    """Memória de Trabalho: Contexto volátil de curta duração durante a execução ativa."""
    def __init__(self):
        self._state: Dict[str, Any] = {}

    def set(self, key: str, value: Any) -> None:
        self._state[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        return self._state.get(key, default)

    def clear(self) -> None:
        self._state.clear()