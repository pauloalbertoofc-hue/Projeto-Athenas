from typing import List, Any

class SemanticMemory:
    """Memória Semântica: Base de conhecimento factual e conceitual (Casulo para buscas vetoriais)."""
    def __init__(self):
        self._knowledge_base: dict[str, Any] = {}

    def store(self, concept: str, data: Any) -> None:
        self._knowledge_base[concept] = data

    def search(self, query: str) -> List[Any]:
        return [v for k, v in self._knowledge_base.items() if query.lower() in k.lower()]