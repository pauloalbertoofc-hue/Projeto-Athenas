from typing import Dict, Any, Optional

class EpisodicMemory:
    """Memória Episódica: Histórico indexado de execuções passadas e snapshots (PCB)."""
    def __init__(self):
        self._episodes: Dict[str, Any] = {}

    def record_episode(self, execution_id: str, snapshot: Dict[str, Any]) -> None:
        self._episodes[execution_id] = snapshot

    def get_episode(self, execution_id: str) -> Optional[Dict[str, Any]]:
        return self._episodes.get(execution_id)