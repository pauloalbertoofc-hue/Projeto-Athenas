from enum import Enum

class ExecutionStatus(Enum):
    CREATED = "created"
    PLANNED = "planned"
    RUNNING = "running"
    FINISHED = "finished"
    FAILED = "failed"
    CANCELLED = "cancelled"