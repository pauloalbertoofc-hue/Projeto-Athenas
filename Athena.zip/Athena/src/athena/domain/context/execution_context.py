from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional, Dict, TYPE_CHECKING
from uuid import uuid4

if TYPE_CHECKING:
    from athena.domain.task import Task
    from athena.domain.workflow import Workflow
    from athena.core.planner import Strategy


class ExecutionStatus(Enum):
    CREATED = "created"
    PLANNED = "planned"
    RUNNING = "running"
    FINISHED = "finished"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class ExecutionMetadata:
    """Telemetria e metadados estruturados da execução."""
    llm: Optional[str] = None
    tokens_used: int = 0
    duration_seconds: float = 0.0
    specialist: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ExecutionContext:
    """
    Process Control Block (PCB) do Kernel da Athena.
    
    Guarda o estado, identidade, telemetria e o ciclo de vida completo
    de uma execução. Puramente focado em dados e transições de estado.
    """
    # Identificação e Árvore de Execução
    task: Task
    execution_id: str = field(default_factory=lambda: str(uuid4()))
    parent_execution_id: Optional[str] = None

    # Estado e Controle de Ciclo de Vida
    status: ExecutionStatus = ExecutionStatus.CREATED

    # Artefatos do Pipeline Cognitivo
    strategy: Optional[Strategy] = None
    workflow: Optional[Workflow] = None
    result: Optional[Dict[str, Any]] = None
    audit: Optional[Dict[str, Any]] = None

    # Telemetria e Temporalidade
    metadata: ExecutionMetadata = field(default_factory=ExecutionMetadata)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    # ==========================================
    # Encapsulamento de Transições de Estado
    # ==========================================

    def touch(self) -> None:
        """Atualiza o timestamp de alteração do PCB."""
        self.updated_at = datetime.now(timezone.utc)

    def set_strategy(self, strategy: Strategy) -> None:
        """Define a estratégia e avança o estado para PLANNED."""
        self.strategy = strategy
        self.status = ExecutionStatus.PLANNED
        self.touch()

    def set_workflow(self, workflow: Workflow) -> None:
        """Define o workflow e avança o estado para RUNNING."""
        self.workflow = workflow
        self.status = ExecutionStatus.RUNNING
        self.touch()

    def set_result(self, result: Dict[str, Any]) -> None:
        """Registra o resultado final e avança o estado para FINISHED."""
        self.result = result
        self.status = ExecutionStatus.FINISHED
        self.touch()

    def set_audit(self, audit: Dict[str, Any]) -> None:
        """Registra o parecer de auditoria/reflexão."""
        self.audit = audit
        self.touch()

    def set_failed(self, error_details: Dict[str, Any]) -> None:
        """Marca a execução como FAILED e registra os detalhes do erro."""
        self.status = ExecutionStatus.FAILED
        self.metadata.extra["error"] = error_details
        self.touch()

    # ==========================================
    # Serialização / Snapshot para Logs e Banco
    # ==========================================

    def snapshot(self) -> Dict[str, Any]:
        return {
            "execution_id": self.execution_id,
            "parent_execution_id": self.parent_execution_id,
            "status": self.status.value,
            "task_id": getattr(self.task, "id", None),
            "planning": {
                "strategy": self.planning.strategy.name if self.planning else None,
                "complexity": self.planning.complexity.name if self.planning else None,
                "priority": self.planning.priority.name if self.planning else None,
                "execution_mode": self.planning.execution_mode.name if self.planning else None,
                "required_processes": [p.value for p in self.planning.required_processes] if self.planning else [],
            } if self.planning else None,
            "workflow": {
                "id": self.workflow.id,
                "name": self.workflow.name,
                "status": self.workflow.status.value,
                "total_steps": len(self.workflow.steps),
                "is_complete": self.workflow.is_complete,
                "has_failed": self.workflow.has_failed_step,
            } if self.workflow else None,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }