from athena.domain.exceptions.kernel import KernelException

class ExecutionException(KernelException):
    """Lançada durante o processamento técnico dos passos do Workflow."""
    pass