from athena.domain.exceptions.kernel import KernelException

class PlanningException(KernelException):
    """Lançada em falhas na etapa de planejamento estratégico."""
    pass