from athena.domain.exceptions.kernel import KernelException

class MemoryException(KernelException):
    """Lançada em falhas de persistência ou consulta na memória cognitiva."""
    pass