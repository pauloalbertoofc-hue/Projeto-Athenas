from athena.domain.exceptions.kernel import KernelException

class WorkflowException(KernelException):
    """Lançada durante a montagem ou validação do Workflow."""
    pass