class KernelException(Exception):
    """Exceção base para todas as falhas dentro do Kernel da Athena."""
    pass