from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, List, Any, Optional, Protocol, runtime_checkable


class ExecutionPolicy(Enum):
    REPLAN = "replan"
    RETRY = "retry"
    FALLBACK = "fallback"
    ABORT = "abort"


@dataclass(frozen=True)
class Event:
    """Evento imutável trafegado no EventBus e registrado no MissionLog."""
    event_id: str
    trace_id: str
    mission_id: str
    agent: str
    slot: str
    event_type: str
    payload: Dict[str, Any]
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    priority: str = "NORMAL"
    blocking: bool = False
    depends_on: List[str] = field(default_factory=list)


@dataclass
class AgentResponse:
    """Retorno padronizado de qualquer Driver/Especialista."""
    agent_id: str
    slot: str
    answer: str
    confidence: float
    citations: List[str] = field(default_factory=list)
    generated_events: List[Event] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MissionPlan:
    """Saída gerada pelo Decision Engine."""
    mission_id: str
    plan_id: str
    plan_version: int
    state_version: int
    goal: str
    steps: List[Dict[str, Any]]
    replan_count: int = 0
    constraints: List[str] = field(default_factory=list)
    preferred_drivers: List[str] = field(default_factory=list)
    expected_events: List[str] = field(default_factory=list)
    execution_policy: ExecutionPolicy = ExecutionPolicy.REPLAN


@dataclass
class PluginManifest:
    """Manifesto de registro de um plugin/driver."""
    id: str
    name: str
    version: str
    slot: str
    author: str
    description: str
    priority: int = 100


@runtime_checkable
class AgentPlugin(Protocol):
    """Interface formal para todo Driver registrado no PluginManager."""
    def think(self, mission_context: Dict[str, Any]) -> AgentResponse: ...
    def review(self, answer: str) -> AgentResponse: ...
    def metadata(self) -> Dict[str, Any]: ...


# -------------------------------------------------------------------
# CONTRATOS DO LLM ADAPTER (SEÇÃO 2 DA ESPECIFICAÇÃO)
# -------------------------------------------------------------------

@dataclass
class LLMResponse:
    text: str
    model: str
    tokens_used: Optional[int] = None
    finish_reason: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


@runtime_checkable
class LLMAdapter(Protocol):
    def generate(self, system_prompt: str, user_prompt: str, **kwargs) -> LLMResponse: ...
    def capabilities(self) -> Dict[str, Any]: ...


class LLMAdapterError(Exception):
    """Erro de geração do LLM — propagado ao Orchestrator para decisão de replanejamento."""
    pass