from enum import Enum, auto

class Complexity(Enum):
    LOW = auto()
    MEDIUM = auto()
    HIGH = auto()
    EXTREME = auto()