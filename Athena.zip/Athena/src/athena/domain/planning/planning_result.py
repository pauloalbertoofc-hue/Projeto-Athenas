from dataclasses import dataclass, field
from typing import List, Optional, Any

from athena.domain.planning.strategy import Strategy
from athena.domain.planning.complexity import Complexity
from athena.domain.planning.priority import Priority
from athena.domain.cognitve_process import CognitiveProcess


@dataclass
class PlanningResult:
    """
    Representa o resultado estratégico gerado pelo Planner para orientar o WorkflowBuilder.
    """
    strategy: Strategy = Strategy.DEFAULT
    complexity: Complexity = Complexity.LOW
    priority: Priority = Priority.NORMAL
    confidence: float = 1.0
    reasoning: str = ""
    estimated_steps: int = 1
    required_processes: List[CognitiveProcess] = field(default_factory=list)
    requires_memory: bool = False
    requires_reflection: bool = False
    estimated_compute_cost: float = 0.0
    estimated_duration_seconds: float = 0.0
    execution_mode: Optional[Any] = None  # Suporte a modo sequencial/paralelo