from enum import Enum, auto

class ExecutionMode(Enum):
    SEQUENTIAL = auto()
    PARALLEL = auto()
    PIPELINE = auto()
    DELIBERATION = auto()