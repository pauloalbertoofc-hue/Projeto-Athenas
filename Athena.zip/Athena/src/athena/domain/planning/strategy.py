from enum import Enum, auto

class Strategy(Enum):
    DEFAULT = auto()
    RESEARCH = auto()
    SUMMARY = auto()
    CODING = auto()
    LEGAL_ANALYSIS = auto()