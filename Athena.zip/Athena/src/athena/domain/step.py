from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any
from uuid import uuid4

class StepStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"

class AgentRole(Enum):
    JUSTITIA = "justitia"      # Especialista Jurídico
    SOPHIA = "sophia"          # Especialista em Filosofia/Raciocínio
    LOGOS = "logos"            # Especialista em Lógica/Programação
    MUSA = "musa"              # Especialista em Criatividade/Texto
    STRATEGOS = "strategos"    # Planejador/Orquestrador
    CRITIAS = "critias"        # Crítico/Revisador
    MNEMOSYNE = "mnemosyne"    # Gerenciador de Memória/Contexto

@dataclass
class Step:
    """
    Representa uma ação concreta e atômica dentro de um plano de execução (Workflow).
    Cada passo possui um agente responsável, regras de ordem, dependências e resiliência.
    """
    name: str
    objective: str
    description: str
    assigned_agent: AgentRole  # Agora tipado fortemente com o Enum de Especialistas
    order: int                 # Define a sequência exata de execução no fluxo
    
    id: str = field(default_factory=lambda: str(uuid4()), repr=False)
    status: StepStatus = StepStatus.PENDING
    
    # Lista de IDs de outros Steps que precisam terminar antes deste começar
    depends_on: list[str] = field(default_factory=list, repr=False)
    
    # Resiliência
    max_retries: int = 3
    current_retry: int = 0
    
    # Dados e Contextos
    input_data: dict[str, Any] = field(default_factory=dict, repr=False)
    output_data: dict[str, Any] = field(default_factory=dict, repr=False)
    context: dict[str, Any] = field(default_factory=dict, repr=False)     # Contexto global compartilhado
    tags: set[str] = field(default_factory=set, repr=False)
    
    # Métricas de tempo
    estimated_duration: float | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    
    created_at: datetime = field(default_factory=datetime.utcnow, repr=False)
    updated_at: datetime = field(default_factory=datetime.utcnow, repr=False)

    def __post_init__(self):
        """Garante a integridade dos dados da ação cognitiva."""
        if not self.name.strip():
            raise ValueError("O nome do passo não pode estar vazio.")
        if not self.objective.strip():
            raise ValueError("O objetivo do passo não pode estar vazio.")
        if not self.description.strip():
            raise ValueError("A descrição do passo não pode estar vazia.")
        if self.order < 0:
            raise ValueError("A ordem do passo não pode ser negativa.")

    @property
    def can_retry(self) -> bool:
        """Indica se o passo ainda possui tentativas de execução restantes."""
        return self.current_retry < self.max_retries

    def _touch(self):
        """Atualiza o timestamp de modificação da etapa."""
        self.updated_at = datetime.utcnow()

    def __str__(self):
        """Representação limpa para logs de execução em tempo real."""
        return f"Step(name='{self.name}', agent='{self.assigned_agent.value}', order={self.order}, status='{self.status.value}')"