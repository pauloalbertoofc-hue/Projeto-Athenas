from enum import Enum

class CognitiveProcess(Enum):
    RESEARCH = "research"
    ANALYSIS = "analysis"
    ARGUMENTATION = "argumentation"
    VALIDATION = "validation"
    SYNTHESIS = "synthesis"