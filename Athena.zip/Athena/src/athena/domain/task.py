from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any
from uuid import uuid4  # Mudança sugerida pelo Tech Lead para melhor legibilidade

class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class TaskPriority(Enum):
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4

class TaskType(Enum):
    SUMMARY = "summary"
    RESEARCH = "research"
    CODING = "coding"
    IMAGE = "image"
    VIDEO = "video"
    PLANNING = "planning"
    REVIEW = "review"

@dataclass
class Task:
    """
    Representa uma unidade de trabalho da Athena.
    Toda solicitação do usuário é convertida em uma Task, que será
    posteriormente transformada em um Workflow executado pelo Runtime.
    """
    title: str
    description: str
    task_type: TaskType
    priority: TaskPriority = TaskPriority.NORMAL
    
    # Usando o uuid4 direto agora
    id: str = field(default_factory=lambda: str(uuid4()), repr=False)
    status: TaskStatus = TaskStatus.PENDING
    assigned_agent: str | None = None
    result: Any = None 
    
    metadata: dict[str, Any] = field(default_factory=dict, repr=False)
    created_at: datetime = field(default_factory=datetime.utcnow, repr=False)
    updated_at: datetime = field(default_factory=datetime.utcnow, repr=False)

    def __post_init__(self):
        """Validações automáticas após a criação da Task."""
        if not self.title.strip():
            raise ValueError("O título da tarefa não pode estar vazio.")
        if not self.description.strip():
            raise ValueError("A descrição da tarefa não pode estar vazia.")

    @property
    def is_finished(self) -> bool:
        """Indica se a tarefa chegou a um estado terminal."""
        return self.status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED)

    def _touch(self):
        """Atualiza o timestamp de modificação da tarefa."""
        self.updated_at = datetime.utcnow()

    def __str__(self):
        """Representação detalhada para depuração em logs."""
        return (
            f"Task("
            f"title='{self.title}', "
            f"type='{self.task_type.value}', "
            f"status='{self.status.value}')"
        )