from enum import Enum

class Capability(Enum):
    LEGAL = "legal"
    LOGIC = "logic"
    KNOWLEDGE = "knowledge"