import uuid
from typing import Dict, Any, Optional
from athena.domain.contracts import AgentPlugin, AgentResponse, PluginManifest, Event, LLMAdapter


class JustitiaDriver(AgentPlugin):
    SYSTEM_PROMPT = (
        "Você é Justitia, especialista jurídica da Athena. Responde com rigor técnico, "
        "cita fundamentação legal apropriada sem inventar dispositivos e sinaliza claramente "
        "quando uma questão exige verificação por um profissional humano. Tom formal, preciso, sem rodeios."
    )

    def __init__(self, llm_adapter: Optional[LLMAdapter] = None):
        self.llm = llm_adapter
        self.bus_context = None

    @staticmethod
    def get_manifest() -> PluginManifest:
        return PluginManifest(
            id="justitia_01",
            name="Justitia",
            version="1.0.0",
            slot="LEGAL_EXPERT",
            author="Paulo",
            description="Direito, Doutrina e Compliance Reativo.",
            priority=100
        )

    def on_register(self, bus_context) -> None:
        """Hook automático disparado pelo PluginManager durante o carregamento."""
        self.bus_context = bus_context
        bus_context.subscribe("NeedSecurityAudit", self.on_security_audit_needed)

    def on_security_audit_needed(self, event: Event) -> None:
        """Reação autônoma do driver a alertas de segurança técnica."""
        target_issue = event.payload.get("target", "Análise de código e infraestrutura")
        prompt_reactive = f"Análise reativa de compliance requisitada devido ao alerta de segurança: '{target_issue}'."

        if self.llm:
            res = self.llm.generate(
                system_prompt=f"{self.SYSTEM_PROMPT}\n\nModo: Análise Reativa de Compliance e Riscos.",
                user_prompt=prompt_reactive
            )
            answer_text = res.text
        else:
            answer_text = f"[JUSTITIA - REATIVO]: Análise de compliance efetuada para '{target_issue}'."

        if self.bus_context:
            compliance_evt = Event(
                event_id=f"evt_{uuid.uuid4().hex[:6]}",
                trace_id=event.trace_id,
                mission_id=event.mission_id,
                agent="justitia_01",
                slot="LEGAL_EXPERT",
                event_type="ComplianceAuditInitiated",
                payload={
                    "answer": answer_text,
                    "triggered_by": event.event_id,
                    "source_agent": event.agent
                }
            )
            self.bus_context.emit(compliance_evt)

    def think(self, mission_context: Dict[str, Any]) -> AgentResponse:
        goal = mission_context.get("goal", "")
        if self.llm:
            res = self.llm.generate(system_prompt=self.SYSTEM_PROMPT, user_prompt=goal)
            return AgentResponse(agent_id="justitia_01", slot="LEGAL_EXPERT", answer=res.text, confidence=0.95, metadata={"model": res.model, "tokens": res.tokens_used})
        return AgentResponse(agent_id="justitia_01", slot="LEGAL_EXPERT", answer=f"[JUSTITIA]: Parecer jurídico elaborado para '{goal}'.", confidence=0.9)

    def review(self, answer: str) -> AgentResponse:
        if self.llm:
            res = self.llm.generate(system_prompt=f"{self.SYSTEM_PROMPT}\n\nModo: revisão de conformidade legal.", user_prompt=answer)
            return AgentResponse(agent_id="justitia_01", slot="LEGAL_EXPERT", answer=res.text, confidence=0.95)
        return AgentResponse(agent_id="justitia_01", slot="LEGAL_EXPERT", answer="[JUSTITIA]: Revisão legal concluída.", confidence=0.9)

    def metadata(self) -> Dict[str, Any]:
        return {"status": "ONLINE", "domain": "law"}


class SophiaDriver(AgentPlugin):
    SYSTEM_PROMPT = (
        "Você é Sophia, especialista literária da Athena. Trabalha com prosa, poesia e crítica literária. "
        "Valoriza ambiguidade interpretativa e evita explicar demais um texto."
    )

    def __init__(self, llm_adapter: Optional[LLMAdapter] = None):
        self.llm = llm_adapter

    @staticmethod
    def get_manifest() -> PluginManifest:
        return PluginManifest(id="sophia_01", name="Sophia", version="1.0.0", slot="LITERARY_EXPERT", author="Paulo", description="Literatura e Escrita", priority=100)

    def think(self, mission_context: Dict[str, Any]) -> AgentResponse:
        goal = mission_context.get("goal", "")
        if self.llm:
            res = self.llm.generate(system_prompt=self.SYSTEM_PROMPT, user_prompt=goal)
            return AgentResponse(agent_id="sophia_01", slot="LITERARY_EXPERT", answer=res.text, confidence=0.92, metadata={"model": res.model})
        return AgentResponse(agent_id="sophia_01", slot="LITERARY_EXPERT", answer=f"[SOPHIA]: Composição poética para '{goal}'.", confidence=0.9)

    def review(self, answer: str) -> AgentResponse:
        if self.llm:
            res = self.llm.generate(system_prompt=f"{self.SYSTEM_PROMPT}\n\nModo: crítica e revisão estilística.", user_prompt=answer)
            return AgentResponse(agent_id="sophia_01", slot="LITERARY_EXPERT", answer=res.text, confidence=0.92)
        return AgentResponse(agent_id="sophia_01", slot="LITERARY_EXPERT", answer="[SOPHIA]: Revisão literária concluída.", confidence=0.9)

    def metadata(self) -> Dict[str, Any]:
        return {"status": "ONLINE", "domain": "literature"}


class LogosDriver(AgentPlugin):
    SYSTEM_PROMPT = (
        "Você é Logos, especialista científica da Athena. Raciocina com método: hipótese, evidência, "
        "limite de confiança. Distingue claramente o que é consenso estabelecido do que é especulativo."
    )

    def __init__(self, llm_adapter: Optional[LLMAdapter] = None):
        self.llm = llm_adapter

    @staticmethod
    def get_manifest() -> PluginManifest:
        return PluginManifest(id="logos_01", name="Logos", version="1.0.0", slot="SCIENCE_EXPERT", author="Paulo", description="Ciência e Lógica", priority=100)

    def think(self, mission_context: Dict[str, Any]) -> AgentResponse:
        goal = mission_context.get("goal", "")
        if self.llm:
            res = self.llm.generate(system_prompt=self.SYSTEM_PROMPT, user_prompt=goal)
            return AgentResponse(agent_id="logos_01", slot="SCIENCE_EXPERT", answer=res.text, confidence=0.99, metadata={"model": res.model})
        return AgentResponse(agent_id="logos_01", slot="SCIENCE_EXPERT", answer=f"[LOGOS]: Análise científica para '{goal}'.", confidence=0.9)

    def review(self, answer: str) -> AgentResponse:
        if self.llm:
            res = self.llm.generate(system_prompt=f"{self.SYSTEM_PROMPT}\n\nModo: validação lógica e empírica.", user_prompt=answer)
            return AgentResponse(agent_id="logos_01", slot="SCIENCE_EXPERT", answer=res.text, confidence=0.99)
        return AgentResponse(agent_id="logos_01", slot="SCIENCE_EXPERT", answer="[LOGOS]: Validação científica concluída.", confidence=0.9)

    def metadata(self) -> Dict[str, Any]:
        return {"status": "ONLINE", "domain": "science"}


class MusaDriver(AgentPlugin):
    SYSTEM_PROMPT = (
        "Você é Musa, especialista criativa da Athena. Atua em desenvolvimento de personagens, "
        "worldbuilding, design narrativo e conceitos visuais. Gera possibilidades amplas."
    )

    def __init__(self, llm_adapter: Optional[LLMAdapter] = None):
        self.llm = llm_adapter

    @staticmethod
    def get_manifest() -> PluginManifest:
        return PluginManifest(id="musa_01", name="Musa", version="1.0.0", slot="CREATIVE_EXPERT", author="Paulo", description="Worldbuilding e Design", priority=100)

    def think(self, mission_context: Dict[str, Any]) -> AgentResponse:
        goal = mission_context.get("goal", "")
        if self.llm:
            res = self.llm.generate(system_prompt=self.SYSTEM_PROMPT, user_prompt=goal)
            return AgentResponse(agent_id="musa_01", slot="CREATIVE_EXPERT", answer=res.text, confidence=0.90, metadata={"model": res.model})
        return AgentResponse(agent_id="musa_01", slot="CREATIVE_EXPERT", answer=f"[MUSA]: Conceituação criativa para '{goal}'.", confidence=0.9)

    def review(self, answer: str) -> AgentResponse:
        if self.llm:
            res = self.llm.generate(system_prompt=f"{self.SYSTEM_PROMPT}\n\nModo: revisão de consistência narrativa.", user_prompt=answer)
            return AgentResponse(agent_id="musa_01", slot="CREATIVE_EXPERT", answer=res.text, confidence=0.90)
        return AgentResponse(agent_id="musa_01", slot="CREATIVE_EXPERT", answer="[MUSA]: Revisão criativa concluída.", confidence=0.9)

    def metadata(self) -> Dict[str, Any]:
        return {"status": "ONLINE", "domain": "creativity"}


class StrategosDriver(AgentPlugin):
    SYSTEM_PROMPT = (
        "Você é Strategos, especialista em planejamento da Athena. Transforma objetivos vagos "
        "em passos concretos, com sequenciamento e priorização explícitos. Sempre termina com 'próximo passo'."
    )

    def __init__(self, llm_adapter: Optional[LLMAdapter] = None):
        self.llm = llm_adapter

    @staticmethod
    def get_manifest() -> PluginManifest:
        return PluginManifest(id="strategos_01", name="Strategos", version="1.0.0", slot="PLANNING_EXPERT", author="Paulo", description="Planejamento e Gestão", priority=100)

    def think(self, mission_context: Dict[str, Any]) -> AgentResponse:
        goal = mission_context.get("goal", "")
        if self.llm:
            res = self.llm.generate(system_prompt=self.SYSTEM_PROMPT, user_prompt=goal)
            return AgentResponse(agent_id="strategos_01", slot="PLANNING_EXPERT", answer=res.text, confidence=0.96, metadata={"model": res.model})
        return AgentResponse(agent_id="strategos_01", slot="PLANNING_EXPERT", answer=f"[STRATEGOS]: Plano de ação para '{goal}'.", confidence=0.9)

    def review(self, answer: str) -> AgentResponse:
        if self.llm:
            res = self.llm.generate(system_prompt=f"{self.SYSTEM_PROMPT}\n\nModo: auditoria de viabilidade do plano.", user_prompt=answer)
            return AgentResponse(agent_id="strategos_01", slot="PLANNING_EXPERT", answer=res.text, confidence=0.96)
        return AgentResponse(agent_id="strategos_01", slot="PLANNING_EXPERT", answer="[STRATEGOS]: Cronograma validado.", confidence=0.9)

    def metadata(self) -> Dict[str, Any]:
        return {"status": "ONLINE", "domain": "planning"}


class MnemosyneDriver(AgentPlugin):
    SYSTEM_PROMPT = (
        "Você é Mnemosyne, especialista em memória e contexto da Athena. Reconstrói e organiza "
        "histórico relevante de uma missão ou projeto, sinalizando lacunas quando a informação não está disponível."
    )

    def __init__(self, llm_adapter: Optional[LLMAdapter] = None):
        self.llm = llm_adapter

    @staticmethod
    def get_manifest() -> PluginManifest:
        return PluginManifest(id="mnemosyne_01", name="Mnemosyne", version="1.0.0", slot="MEMORY_EXPERT", author="Paulo", description="Contexto e Histórico", priority=100)

    def think(self, mission_context: Dict[str, Any]) -> AgentResponse:
        goal = mission_context.get("goal", "")
        if self.llm:
            res = self.llm.generate(system_prompt=self.SYSTEM_PROMPT, user_prompt=goal)
            return AgentResponse(agent_id="mnemosyne_01", slot="MEMORY_EXPERT", answer=res.text, confidence=0.93, metadata={"model": res.model})
        return AgentResponse(agent_id="mnemosyne_01", slot="MEMORY_EXPERT", answer=f"[MNEMOSYNE]: Recuperação do histórico para '{goal}'.", confidence=0.9)

    def review(self, answer: str) -> AgentResponse:
        if self.llm:
            res = self.llm.generate(system_prompt=f"{self.SYSTEM_PROMPT}\n\nModo: verificação de consistência histórica.", user_prompt=answer)
            return AgentResponse(agent_id="mnemosyne_01", slot="MEMORY_EXPERT", answer=res.text, confidence=0.93)
        return AgentResponse(agent_id="mnemosyne_01", slot="MEMORY_EXPERT", answer="[MNEMOSYNE]: Histórico validado.", confidence=0.9)

    def metadata(self) -> Dict[str, Any]:
        return {"status": "ONLINE", "domain": "memory"}


class CritiasDriver(AgentPlugin):
    SYSTEM_PROMPT = (
        "Você é Critias, o revisor da Athena. Não gera conteúdo novo — audita o que outros "
        "especialistas produziram, aponta inconsistências, exageros, erros factuais ou lacunas lógicas. "
        "Tom construtivo mas direto. Nunca reescreve por conta própria — sinaliza o que precisa de ajuste e por quê."
    )

    def __init__(self, llm_adapter: Optional[LLMAdapter] = None):
        self.llm = llm_adapter

    @staticmethod
    def get_manifest() -> PluginManifest:
        return PluginManifest(id="critias_01", name="Critias", version="1.0.0", slot="AUDITOR", author="Paulo", description="Auditoria Crítica", priority=100)

    def think(self, mission_context: Dict[str, Any]) -> AgentResponse:
        goal = mission_context.get("goal", "")
        if self.llm:
            res = self.llm.generate(system_prompt=self.SYSTEM_PROMPT, user_prompt=goal)
            return AgentResponse(agent_id="critias_01", slot="AUDITOR", answer=res.text, confidence=0.98, metadata={"model": res.model})
        return AgentResponse(agent_id="critias_01", slot="AUDITOR", answer=f"[CRITIAS]: Análise crítica direta para '{goal}'.", confidence=0.9)

    def review(self, answer: str) -> AgentResponse:
        if self.llm:
            prompt_review = f"{self.SYSTEM_PROMPT}\n\nAnalise o seguinte conteúdo produzido pelos especialistas anteriores e aponte inconsistências ou validações de integridade:"
            res = self.llm.generate(system_prompt=prompt_review, user_prompt=answer)
            return AgentResponse(agent_id="critias_01", slot="AUDITOR", answer=res.text, confidence=0.99)
        return AgentResponse(agent_id="critias_01", slot="AUDITOR", answer="[CRITIAS]: Parecer crítico sem alucinações.", confidence=0.9)

    def metadata(self) -> Dict[str, Any]:
        return {"status": "ONLINE", "domain": "audit"}