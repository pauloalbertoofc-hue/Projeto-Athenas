from abc import ABC, abstractmethod

class Specialist(ABC):
    capability = None

    @abstractmethod
    def execute(self, context: dict):
        raise NotImplementedError("Especialistas devem implementar o método execute.")