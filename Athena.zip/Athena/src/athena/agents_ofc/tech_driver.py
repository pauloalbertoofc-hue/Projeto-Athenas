import uuid
from typing import Dict, Any, Optional
from athena.domain.contracts import AgentPlugin, AgentResponse, PluginManifest, Event, LLMAdapter


class TechDriver(AgentPlugin):
    """Driver especialista do slot TECH_EXPERT."""

    SYSTEM_PROMPT = (
        "Você é Tech, especialista técnico da Athena. Cobre programação, arquitetura de sistemas, "
        "infraestrutura e TI. Tom pragmático, prioriza soluções funcionais sobre elegância teórica."
    )

    def __init__(self, llm_adapter: Optional[LLMAdapter] = None):
        self.llm = llm_adapter

    @staticmethod
    def get_manifest() -> PluginManifest:
        return PluginManifest(
            id="tech_driver_01",
            name="Tech Specialist Driver",
            version="1.0.0",
            slot="TECH_EXPERT",
            author="Paulo",
            description="Driver de infraestrutura e engenharia técnica.",
            priority=100
        )

    def think(self, mission_context: Dict[str, Any]) -> AgentResponse:
        goal = mission_context.get("goal", "")
        mission_id = mission_context.get("mission_id", "unknown")

        if self.llm:
            result = self.llm.generate(
                system_prompt=self.SYSTEM_PROMPT,
                user_prompt=goal
            )
            answer = result.text
            model_used = result.model
            tokens = result.tokens_used
        else:
            answer = f"[TECH]: Análise técnica executada para '{goal}'."
            model_used = "fallback-static"
            tokens = 0

        # Disparo CONDICIONAL de evento de domínio
        generated_events = []
        security_terms = ["segurança", "vulnerabilidade", "bug", "senha", "hack", "audit"]
        if any(term in goal.lower() or term in answer.lower() for term in security_terms):
            evt_need = Event(
                event_id=f"evt_{uuid.uuid4().hex[:6]}",
                trace_id=mission_id,
                mission_id=mission_id,
                agent="tech_driver_01",
                slot="TECH_EXPERT",
                event_type="NeedSecurityAudit",
                payload={"source": "TechDriver", "target": goal}
            )
            generated_events.append(evt_need)

        return AgentResponse(
            agent_id="tech_driver_01",
            slot="TECH_EXPERT",
            answer=answer,
            confidence=0.95,
            citations=["Documentação da Athena COS"],
            generated_events=generated_events,
            metadata={"model": model_used, "tokens_used": tokens}
        )

    def review(self, answer: str) -> AgentResponse:
        if self.llm:
            result = self.llm.generate(
                system_prompt=f"{self.SYSTEM_PROMPT}\n\nModo: revisão técnica de código e infraestrutura.",
                user_prompt=answer
            )
            rev_text = result.text
        else:
            rev_text = f"[TECH]: Revisão técnica confirmada sem vulnerabilidades."

        return AgentResponse(
            agent_id="tech_driver_01",
            slot="TECH_EXPERT",
            answer=rev_text,
            confidence=0.98
        )

    def metadata(self) -> Dict[str, Any]:
        return {"status": "ONLINE", "capabilities": ["python", "kernel", "math"]}