import importlib
import inspect
import pkgutil
from typing import TYPE_CHECKING

import athena.agents_ofc
from athena.agents_ofc.base_agent import Specialist

if TYPE_CHECKING:
    from athena.core.registry import SpecialistRegistry

def autodiscover_specialists(registry: "SpecialistRegistry") -> None:
    """
    Descobre especialistas no pacote 'athena.agents' e registra suas CLASSES no Registry.
    Não conhece o Router nem interfere no roteamento.
    """
    package = athena.agents_ofc

    # walk_packages permite encontrar arquivos em subpastas dentro de agents/
    for _, module_name, _ in pkgutil.walk_packages(package.__path__, package.__name__ + "."):
        if "base_agent" in module_name or "loader" in module_name:
            continue

        module = importlib.import_module(module_name)

        for _, obj in inspect.getmembers(module, inspect.isclass):
            if issubclass(obj, Specialist) and obj is not Specialist:
                # REGISTRA A CLASSE (obj), NÃO A INSTÂNCIA (obj())
                registry.register(obj)