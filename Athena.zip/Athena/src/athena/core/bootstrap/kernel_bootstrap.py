from athena.core.planners.rule_planner import RulePlanner
from athena.core.reflections.basic_reflection import BasicReflection
from athena.core.registry import SpecialistRegistry
from athena.core.router import Router
from athena.core.memory import Memory
from athena.core.agent_runner import AgentRunner
from athena.core.executive_core import ExecutiveCore
from athena.core.executive_controller import ExecutiveController
from athena.core.workflow_builder import WorkflowBuilder
from athena.core.workflow_executor import WorkflowExecutor
from athena.agents_ofc.loader import autodiscover_specialists

class KernelBootstrap:
    @staticmethod
    def build() -> ExecutiveController:
        planner = RulePlanner()
        reflection = BasicReflection()
        memory = Memory()

        registry = SpecialistRegistry()
        autodiscover_specialists(registry)

        router = Router(registry=registry)
        builder = WorkflowBuilder()
        
        # Injeção do AgentRunner no Executor
        agent_runner = AgentRunner()
        executor = WorkflowExecutor(router=router, agent_runner=agent_runner)

        core = ExecutiveCore(
            planner=planner,
            memory=memory,
            router=router,
            workflow_builder=builder,
            workflow_executor=executor,
            reflection=reflection
        )

        return ExecutiveController(core=core)