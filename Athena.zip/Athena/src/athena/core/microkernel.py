import uuid
from typing import Dict, Any, List, Optional, Callable
from athena.domain.contracts import Event, AgentPlugin


class KernelBusContext:
    """Contexto de privilégio restrito concedido aos plugins para publicar, assinar e registrar eventos."""

    def __init__(self, subscribe_fn: Callable, emit_fn: Callable, register_admin_fn: Callable):
        self._subscribe_fn = subscribe_fn
        self._emit_fn = emit_fn
        self._register_admin_fn = register_admin_fn

    def subscribe(self, event_type: str, handler: Callable) -> None:
        self._subscribe_fn(event_type, handler)

    def emit(self, event: Event) -> None:
        self._emit_fn(event)

    def register_admin_event(self, event_type: str) -> None:
        """Permite que um driver cadastre eventos de infraestrutura/admin dinamicamente."""
        self._register_admin_fn(event_type)


class EventBus:
    """Barramento de eventos com contagem de inscritos para detecção de eventos órfãos."""

    def __init__(self):
        self._subscribers: Dict[str, List[Callable]] = {}

    def subscribe(self, event_type: str, handler: Callable) -> None:
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        self._subscribers[event_type].append(handler)

    def publish(self, event: Event) -> int:
        """Publica o evento e retorna o número de handlers executados."""
        handlers = self._subscribers.get(event.event_type, [])
        for handler in handlers:
            handler(event)
        return len(handlers)


class SlotRegistry:
    """Registro e resolução de drivers por slot."""

    def __init__(self):
        self._slots: Dict[str, List[AgentPlugin]] = {}

    def register_driver(self, slot: str, driver: AgentPlugin) -> None:
        if slot not in self._slots:
            self._slots[slot] = []
        self._slots[slot].append(driver)

    def get_best_driver(self, slot: str) -> Optional[AgentPlugin]:
        drivers = self._slots.get(slot, [])
        if not drivers:
            return None
        return sorted(drivers, key=lambda d: d.get_manifest().priority, reverse=True)[0]


class PluginManager:
    """Gerenciador de plugins com Auto-Wiring Reativo Automático."""

    def __init__(self, slot_registry: SlotRegistry, kernel_bus_context: Optional[KernelBusContext] = None):
        self.slot_registry = slot_registry
        self.kernel_bus_context = kernel_bus_context
        self.plugins: Dict[str, AgentPlugin] = {}

    def load_plugin(self, plugin: AgentPlugin) -> None:
        manifest = plugin.get_manifest()
        self.plugins[manifest.id] = plugin
        self.slot_registry.register_driver(manifest.slot, plugin)

        # Hook Automático de Registro: ativa a reatividade se o plugin tiver 'on_register'
        if hasattr(plugin, "on_register") and callable(getattr(plugin, "on_register")):
            if self.kernel_bus_context:
                plugin.on_register(self.kernel_bus_context)


class MissionLogAndState:
    """Estrutura isolada de log imutável e projeção de estado por missão."""

    def __init__(self, mission_id: str, goal: str):
        self.mission_id = mission_id
        self.goal = goal
        self.log: List[Event] = []
        self.state: Dict[str, Any] = {
            "mission_id": mission_id,
            "goal": goal,
            "status": "CREATED",
            "completed_steps": [],
            "replan_count": 0,
            "state_version": 0,
        }

    def append_and_project(self, event: Event) -> None:
        self.log.append(event)
        self.state["state_version"] += 1

        if event.event_type == "MissionStarted":
            self.state["status"] = "IN_PROGRESS"
        elif event.event_type == "StepCompleted":
            step_id = event.payload.get("step_id")
            if step_id and step_id not in self.state["completed_steps"]:
                self.state["completed_steps"].append(step_id)
        elif event.event_type == "PlanApproved":
            self.state["replan_count"] = event.payload.get("replan_count", 0)
        elif event.event_type == "MissionCompleted":
            self.state["status"] = "COMPLETED"
        elif event.event_type == "MissionFailed":
            self.state["status"] = "FAILED"


class MicroKernel:
    """Microkernel reativo com barramento de eventos sem whitelists prévias de schema."""

    # Eventos de ciclo de vida do sistema que não requerem inscritos por padrão
    ADMIN_EVENTS_IGNORE_UNHANDLED = {
        "MissionStarted",
        "PlanApproved",
        "StepCompleted",
        "MissionCompleted",
        "MissionFailed",
        "PlanInvalidated",
        "NoDriverForSlot",
        "DriverExecutionFailed",
        "ComplianceAuditInitiated",
        "EventUnhandled",
    }

    def __init__(self):
        self.event_bus = EventBus()
        self.slot_registry = SlotRegistry()
        self.active_missions: Dict[str, MissionLogAndState] = {}

        self.bus_context = KernelBusContext(
            subscribe_fn=self.event_bus.subscribe,
            emit_fn=self.emit_event,
            register_admin_fn=self.register_admin_event
        )

        self.plugin_manager = PluginManager(self.slot_registry, kernel_bus_context=self.bus_context)

    def register_admin_event(self, event_type: str) -> None:
        """Cadastra dinamicamente um tipo de evento para ser ignorado na checagem de evento órfão."""
        self.ADMIN_EVENTS_IGNORE_UNHANDLED.add(event_type)

    def create_mission(self, goal: str) -> str:
        mission_id = f"miss_{uuid.uuid4().hex[:6]}"
        log_and_state = MissionLogAndState(mission_id, goal)
        self.active_missions[mission_id] = log_and_state

        start_evt = Event(
            event_id=f"evt_{uuid.uuid4().hex[:6]}",
            trace_id=mission_id,
            mission_id=mission_id,
            agent="KERNEL",
            slot="SYSTEM",
            event_type="MissionStarted",
            payload={"goal": goal}
        )
        self.emit_event(start_evt)
        return mission_id

    def emit_event(self, event: Event) -> None:
        """Grava o evento no Log e publica no Barramento. Se nenhum ouvinte receber, registra EventUnhandled."""
        self._record_event(event)
        listeners_count = self.event_bus.publish(event)

        if listeners_count == 0 and event.event_type not in self.ADMIN_EVENTS_IGNORE_UNHANDLED:
            unhandled = Event(
                event_id=f"evt_{uuid.uuid4().hex[:6]}",
                trace_id=event.trace_id,
                mission_id=event.mission_id,
                agent="KERNEL",
                slot="SYSTEM",
                event_type="EventUnhandled",
                payload={"unhandled_event_type": event.event_type, "original_event_id": event.event_id}
            )
            self._record_event(unhandled)

    def _record_event(self, event: Event) -> None:
        mission_id = event.mission_id
        if mission_id in self.active_missions:
            self.active_missions[mission_id].append_and_project(event)  