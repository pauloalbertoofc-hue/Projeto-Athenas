from __future__ import annotations
import re
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, List

from athena.domain.planning.strategy import Strategy
from athena.domain.planning.complexity import Complexity
from athena.domain.planning.priority import Priority
from athena.domain.planning.planning_result import PlanningResult
from athena.domain.cognitve_process import CognitiveProcess

if TYPE_CHECKING:
    from athena.domain.task import Task


class Planner(ABC):
    """Contrato abstrato para qualquer motor de planejamento da Athena."""

    @abstractmethod
    def plan(self, task: Task) -> PlanningResult:
        """Transforma uma Task em uma Ordem de Missão estratégica (PlanningResult)."""
        pass


class RulePlanner(Planner):
    """
    Planejador baseado em regras heurísticas dinâmicas.
    Inspeciona a Task e decide a estratégia, complexidade e processos necessários.
    """

    def plan(self, task: Task) -> PlanningResult:
        raw_text = (getattr(task, 'description', '') or getattr(task, 'title', '') or '').strip()
        text_lower = raw_text.lower()

        # -------------------------------------------------------------------
        # REGRA 1: Expressões Matemáticas Diretas (ex: "2+2", "56*23")
        # -------------------------------------------------------------------
        if self._is_math_expression(raw_text):
            return PlanningResult(
                strategy=getattr(Strategy, 'DIRECT_ANSWER', Strategy.DEFAULT),
                complexity=Complexity.LOW,
                priority=Priority.NORMAL,
                confidence=1.0,
                reasoning="Cálculo matemático direto detectado. Resposta imediata sem pesquisa.",
                estimated_steps=1,
                required_processes=[CognitiveProcess.ANALYSIS],
                requires_memory=False,
                requires_reflection=False,
                estimated_compute_cost=0.1,
                estimated_duration_seconds=0.1
            )

        # -------------------------------------------------------------------
        # REGRA 2: Domínio Jurídico (ex: "artigo 121", "petição", "réu")
        # -------------------------------------------------------------------
        legal_keywords = ["direito", "lei", "artigo", "código", "cf", "penal", "processo", "petição", "réu", "juiz", "jurisprudência"]
        if any(kw in text_lower for kw in legal_keywords):
            return PlanningResult(
                strategy=getattr(Strategy, 'LEGAL_ANALYSIS', Strategy.DEFAULT),
                complexity=Complexity.HIGH if len(raw_text) > 60 else Complexity.MEDIUM,
                priority=Priority.HIGH,
                confidence=0.95,
                reasoning="Demanda jurídica identificada. Ativando busca em memória e validação formal.",
                estimated_steps=3,
                required_processes=[CognitiveProcess.ANALYSIS, CognitiveProcess.VALIDATION],
                requires_memory=True,
                requires_reflection=True,
                estimated_compute_cost=1.5,
                estimated_duration_seconds=1.0
            )

        # -------------------------------------------------------------------
        # REGRA 3: Perguntas Curtas ou Conceituais (ex: "o que é kernel?", "ola")
        # -------------------------------------------------------------------
        if len(text_lower.split()) <= 4 or "kernel" in text_lower or "athena" in text_lower:
            return PlanningResult(
                strategy=getattr(Strategy, 'DIRECT_ANSWER', Strategy.DEFAULT),
                complexity=Complexity.LOW,
                priority=Priority.NORMAL,
                confidence=0.9,
                reasoning="Consulta conceitual curta. Resposta direta.",
                estimated_steps=1,
                required_processes=[CognitiveProcess.ANALYSIS],
                requires_memory=True,
                requires_reflection=False,
                estimated_compute_cost=0.3,
                estimated_duration_seconds=0.3
            )

        # -------------------------------------------------------------------
        # REGRA 4: Fallback Geral
        # -------------------------------------------------------------------
        return PlanningResult(
            strategy=Strategy.DEFAULT,
            complexity=Complexity.MEDIUM,
            priority=Priority.NORMAL,
            confidence=0.85,
            reasoning="Análise por regras concluída. Aplicando fluxo padrão.",
            estimated_steps=2,
            required_processes=[CognitiveProcess.ANALYSIS, CognitiveProcess.VALIDATION],
            requires_memory=True,
            requires_reflection=True,
            estimated_compute_cost=1.0,
            estimated_duration_seconds=0.5
        )

    def _is_math_expression(self, text: str) -> bool:
        """Verifica se o texto é uma expressão matemática simples."""
        clean = text.replace(" ", "")
        has_math_chars = bool(re.match(r"^[\d\.\+\-\*\/\(\)\%\^]+$", clean))
        has_operator = any(op in clean for op in "+-*/%^")
        return has_math_chars and has_operator