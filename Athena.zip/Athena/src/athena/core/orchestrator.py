import time
import uuid
from typing import Dict, Any, Optional, List
from athena.domain.contracts import MissionPlan, ExecutionPolicy, Event, LLMAdapterError
from athena.core.microkernel import MicroKernel

DRIVER_KEYWORDS: Dict[str, List[str]] = {
    "LEGAL_EXPERT":   ["direito", "lei", "processo", "jurisprudência", "petição", "contrato", "recurso", "juiz", "réu"],
    "LITERARY_EXPERT":["poema", "poesia", "livro", "narrativa", "prosa", "texto literário", "verso", "literatura"],
    "SCIENCE_EXPERT": ["ciência", "pesquisa", "hipótese", "estatística", "método científico", "dados", "experimento"],
    "CREATIVE_EXPERT":["personagem", "design", "arte", "ilustração", "worldbuilding", "criativo", "história"],
    "PLANNING_EXPERT":["planejar", "organizar", "cronograma", "roadmap", "prioridade", "gestão", "plano"],
    "MEMORY_EXPERT":  ["lembrar", "histórico", "memória", "contexto anterior", "o que já discutimos"],
    "TECH_EXPERT":    ["código", "programação", "sistema", "bug", "arquitetura de software", "api", "python", "2+2", "cálculo", "segurança", "vulnerabilidade"],
}


def match_domains(goal: str) -> List[str]:
    goal_lower = goal.lower()
    matched = []
    for slot, keywords in DRIVER_KEYWORDS.items():
        if any(kw in goal_lower for kw in keywords):
            matched.append(slot)
    return matched


def should_invoke_critias(goal: str, matched_slots: List[str]) -> bool:
    review_keywords = ["revise", "audite", "encontre erros", "valide", "critique", "revisar", "auditar"]
    explicit = any(kw in goal.lower() for kw in review_keywords)
    multi_domain = len(matched_slots) >= 2
    return explicit or multi_domain


class DecisionEngineV1:
    """Módulo de Decisão Determinístico Multi-Domínio V1."""
    MAX_REPLANS = 3

    def __init__(self, custom_steps_sequence: Optional[List[List[Dict[str, Any]]]] = None):
        self.custom_steps_sequence = custom_steps_sequence

    def build_plan(self, goal: str, mission_id: str, state_version: int, replan_count: int = 0) -> MissionPlan:
        if self.custom_steps_sequence and replan_count < len(self.custom_steps_sequence):
            steps = self.custom_steps_sequence[replan_count]
        else:
            matched_slots = match_domains(goal)

            if not matched_slots and not should_invoke_critias(goal, matched_slots):
                matched_slots = ["LITERARY_EXPERT"]

            steps = []
            for i, slot in enumerate(matched_slots, start=1):
                steps.append({
                    "step_id": f"step_{i:02d}_{slot.lower()}",
                    "slot": slot,
                    "action": "think",
                    "depends_on": []
                })

            if should_invoke_critias(goal, matched_slots):
                prev_ids = [s["step_id"] for s in steps]
                steps.append({
                    "step_id": f"step_{len(steps)+1:02d}_auditor",
                    "slot": "AUDITOR",
                    "action": "review",
                    "depends_on": prev_ids
                })

        return MissionPlan(
            mission_id=mission_id,
            plan_id=f"plan_{uuid.uuid4().hex[:6]}",
            plan_version=replan_count + 1,
            state_version=state_version,
            replan_count=replan_count,
            goal=goal,
            steps=steps,
            execution_policy=ExecutionPolicy.REPLAN
        )


class MissionOrchestrator:
    """Orquestrador reativo com tratamento de falha do LLM e Backoff progressivo."""

    def __init__(self, kernel: MicroKernel, decision_engine: DecisionEngineV1):
        self.kernel = kernel
        self.decision_engine = decision_engine

    def run_mission(self, goal: str, mission_id: Optional[str] = None) -> Dict[str, Any]:
        if not mission_id:
            mission_id = self.kernel.create_mission(goal)

        log_and_state = self.kernel.active_missions.get(mission_id)
        if not log_and_state:
            raise ValueError(f"Missão ID '{mission_id}' não encontrada no Kernel.")

        step_outputs: Dict[str, str] = {}
        for evt in log_and_state.log:
            if evt.event_type == "StepCompleted":
                s_id = evt.payload.get("step_id")
                s_ans = evt.payload.get("answer")
                if s_id and s_ans:
                    step_outputs[s_id] = s_ans

        current_status = log_and_state.state.get("status")
        if current_status in ("COMPLETED", "FAILED"):
            print(f" 🛑 [ORCHESTRATOR] Missão '{mission_id}' já encerrada com status [{current_status}]. Retornando Log.")
            return {
                "mission_id": mission_id,
                "final_state": log_and_state.state,
                "output": "\n".join(step_outputs.values()),
                "log_history": log_and_state.log
            }

        replan_count = log_and_state.state.get("replan_count", 0)
        max_replans = self.decision_engine.MAX_REPLANS

        while replan_count <= max_replans:
            plan = self.decision_engine.build_plan(
                goal=goal, 
                mission_id=mission_id, 
                state_version=log_and_state.state["state_version"],
                replan_count=replan_count
            )

            self.kernel.emit_event(Event(
                event_id=f"evt_{uuid.uuid4().hex[:6]}",
                trace_id=mission_id,
                mission_id=mission_id,
                agent="DECISION_ENGINE",
                slot="SYSTEM",
                event_type="PlanApproved",
                payload={"plan_id": plan.plan_id, "plan_version": plan.plan_version, "replan_count": replan_count}
            ))

            plan_invalidated = False

            for step in plan.steps:
                step_id = step["step_id"]
                slot = step["slot"]
                action = step.get("action", "think")

                if step_id in log_and_state.state["completed_steps"]:
                    print(f"   [IDEMPOTÊNCIA] ⏭️ Passo '{step_id}' já concluído. Pulando!")
                    continue

                driver = self.kernel.slot_registry.get_best_driver(slot)

                if not driver:
                    self.kernel.emit_event(Event(
                        event_id=f"evt_{uuid.uuid4().hex[:6]}",
                        trace_id=mission_id,
                        mission_id=mission_id,
                        agent="ORCHESTRATOR",
                        slot=slot,
                        event_type="NoDriverForSlot",
                        payload={"slot": slot, "step_id": step_id}
                    ))

                    self.kernel.emit_event(Event(
                        event_id=f"evt_{uuid.uuid4().hex[:6]}",
                        trace_id=mission_id,
                        mission_id=mission_id,
                        agent="ORCHESTRATOR",
                        slot="SYSTEM",
                        event_type="PlanInvalidated",
                        payload={"failed_step": step_id, "failed_slot": slot}
                    ))

                    plan_invalidated = True
                    replan_count += 1
                    break

                try:
                    if action == "review":
                        accumulated_context = "\n".join(step_outputs.values()) if step_outputs else goal
                        response = driver.review(accumulated_context)
                    else:
                        response = driver.think({"goal": goal, "mission_id": mission_id})

                except LLMAdapterError as err:
                    # 📌 BACKOFF PROGRESSIVO: Aguarda antes de tentar o próximo replanejamento por falha de API
                    backoff_sec = (replan_count + 1) * 1.5
                    print(f" ⚠️ [ORCHESTRATOR] Falha no LLM: {err}. Aplicando backoff de {backoff_sec}s...")
                    time.sleep(backoff_sec)

                    self.kernel.emit_event(Event(
                        event_id=f"evt_{uuid.uuid4().hex[:6]}",
                        trace_id=mission_id,
                        mission_id=mission_id,
                        agent="ORCHESTRATOR",
                        slot=slot,
                        event_type="DriverExecutionFailed",
                        payload={"step_id": step_id, "reason": str(err)}
                    ))

                    self.kernel.emit_event(Event(
                        event_id=f"evt_{uuid.uuid4().hex[:6]}",
                        trace_id=mission_id,
                        mission_id=mission_id,
                        agent="ORCHESTRATOR",
                        slot="SYSTEM",
                        event_type="PlanInvalidated",
                        payload={"failed_step": step_id, "reason": "LLM_FAILURE"}
                    ))

                    plan_invalidated = True
                    replan_count += 1
                    break

                step_outputs[step_id] = response.answer

                for gen_evt in response.generated_events:
                    self.kernel.emit_event(gen_evt)

                self.kernel.emit_event(Event(
                    event_id=f"evt_{uuid.uuid4().hex[:6]}",
                    trace_id=mission_id,
                    mission_id=mission_id,
                    agent=response.agent_id,
                    slot=response.slot,
                    event_type="StepCompleted",
                    payload={"step_id": step_id, "answer": response.answer}
                ))

            if not plan_invalidated:
                self.kernel.emit_event(Event(
                    event_id=f"evt_{uuid.uuid4().hex[:6]}",
                    trace_id=mission_id,
                    mission_id=mission_id,
                    agent="KERNEL",
                    slot="SYSTEM",
                    event_type="MissionCompleted",
                    payload={"status": "SUCCESS"}
                ))
                break

        if replan_count > max_replans:
            self.kernel.emit_event(Event(
                event_id=f"evt_{uuid.uuid4().hex[:6]}",
                trace_id=mission_id,
                mission_id=mission_id,
                agent="KERNEL",
                slot="SYSTEM",
                event_type="MissionFailed",
                payload={"reason": f"Excedido limite de {max_replans} replanejamentos."}
            ))

        return {
            "mission_id": mission_id,
            "final_state": log_and_state.state,
            "output": "\n".join(step_outputs.values()),
            "log_history": log_and_state.log
        }