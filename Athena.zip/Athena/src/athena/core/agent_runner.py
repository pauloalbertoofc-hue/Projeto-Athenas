import time
import re
from typing import Dict, Any, Optional


class AgentRunner:
    """
    Executor e invólucro (wrapper) de resiliência para Especialistas.
    Garante que o resultado do Step (inclusive cálculos) seja repassado com telemetria.
    """

    def run_specialist(self, specialist: Any, context: Dict[str, Any]) -> Dict[str, Any]:
        """Executa um especialista real capturando tempo de execução e telemetria técnica."""
        start_time = time.time()
        try:
            output = specialist.run(context)
            elapsed_time = time.time() - start_time

            if isinstance(output, dict):
                output["_telemetry"] = {
                    "duration_seconds": round(elapsed_time, 4),
                    "agent_class": specialist.__class__.__name__
                }
            return output
        except Exception as e:
            raise RuntimeError(f"Falha na execução do agente '{specialist.__class__.__name__}': {str(e)}")

    def run(self, step: Any) -> Dict[str, Any]:
        """
        Método de interface para o WorkflowExecutor processar um Step.
        Prioriza o resultado gerado no Step e injeta a telemetria.
        """
        start_time = time.time()

        # Atributos do Step com extração segura
        step_name = getattr(step, "name", None) or getattr(step, "title", "Etapa de Execução")
        agent = getattr(step, "assigned_agent", "Especialista")
        agent_name = getattr(agent, "value", str(agent)).upper() if agent else "ESPECIALISTA"
        description = getattr(step, "description", "") or ""
        objective = getattr(step, "objective", "") or ""

        # 1. Se existir um agente real configurado, despacha para ele
        specialist_instance = getattr(step, "specialist_instance", None)
        if specialist_instance and hasattr(specialist_instance, "run"):
            return self.run_specialist(specialist_instance, {"description": description, "step_name": step_name})

        # 2. Se o WorkflowBuilder já calculou a resposta no description (ex: "Resultado do cálculo: 2-2 = 0")
        if description and ("Resultado do cálculo:" in description or "Resultado:" in description or "Resposta direta:" in description):
            final_output = f"[{agent_name}]: {description}"
        else:
            # Fallback dinâmico para outras consultas
            final_output = self._evaluate_fallback_text(agent_name, step_name, description, objective)

        elapsed_time = time.time() - start_time

        return {
            "status": "success",
            "agent": agent_name,
            "output": final_output,
            "_telemetry": {
                "duration_seconds": round(elapsed_time, 4),
                "agent_class": agent_name
            }
        }

    def _evaluate_fallback_text(self, agent_name: str, step_name: str, description: str, objective: str) -> str:
        text_source = description or objective or step_name
        
        # Resposta para cálculos não formatados previamente
        clean_query = text_source.replace(" ", "")
        if any(op in clean_query for op in "+-*/%") and re.match(r"^[\d\.\+\-\*\/\(\)\%\^]+$", clean_query):
            try:
                res = eval(clean_query)
                return f"[{agent_name} - LOGOS]: {text_source} = {res}"
            except Exception:
                pass

        return f"[{agent_name}]: {step_name} executado com êxito. ({text_source})"


# Alias de compatibilidade
MockAgentRunner = AgentRunner