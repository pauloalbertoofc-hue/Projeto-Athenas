import re
from athena.domain.task import Task, TaskType
from athena.domain.workflow import Workflow
from athena.domain.step import Step, AgentRole


class WorkflowBuilder:
    """
    Responsável por traduzir uma Task (o objetivo macro) em um Workflow (o plano tático).
    Opera de forma dinâmica, injetando o contexto e o texto do usuário em cada etapa.
    """

    def build(self, task: Task) -> Workflow:
        """Recebe uma Task e fabrica o Workflow estratégico correspondente."""
        workflow = Workflow(
            name=f"Workflow para: {task.title}",
            description=f"Plano de execução gerado automaticamente para a tarefa ID: {task.id}"
        )

        shared_context = {
            "task_id": task.id,
            "task_priority": getattr(task.priority, 'name', 'NORMAL'),
            "language": "pt-BR"
        }

        base_input = {
            "task_title": task.title,
            "task_description": task.description
        }

        user_text = (task.description or task.title or "").strip()

        # 1. Se for uma expressão matemática simples (ex: 2+2, 10*5), resolve na hora
        if self._is_math_expression(user_text):
            self._plan_math_direct(workflow, user_text, base_input, shared_context)
            return workflow

        # 2. Detecta o tipo real da tarefa inspecionando o texto enviado
        real_task_type = self._detect_task_type(user_text, task.task_type)

        # 3. Roteamento dinâmico
        if real_task_type == TaskType.RESEARCH:
            self._plan_research(workflow, user_text, base_input, shared_context)
        elif real_task_type == TaskType.SUMMARY:
            self._plan_summary(workflow, user_text, base_input, shared_context)
        elif real_task_type == TaskType.CODING:
            self._plan_coding(workflow, user_text, base_input, shared_context)
        else:
            self._plan_default(workflow, user_text, base_input, shared_context)

        return workflow

    def _is_math_expression(self, text: str) -> bool:
        """Verifica se o texto é uma expressão aritmética direta."""
        clean = text.replace(" ", "")
        return bool(re.match(r"^[\d\.\+\-\*\/\(\)\%\^]+$", clean)) and any(op in clean for op in "+-*/%^")

    def _detect_task_type(self, text: str, default_type: TaskType) -> TaskType:
        """Analisa o texto do usuário para classificar a tarefa de forma dinâmica."""
        text_lower = text.lower()
        if any(kw in text_lower for kw in ["código", "python", "script", "função", "def ", "class "]):
            return TaskType.CODING
        if any(kw in text_lower for kw in ["resuma", "resumo", "sintetize", "tópicos"]):
            return TaskType.SUMMARY
        # Pergunta conceitual curta (ex: "o que é kernel?") -> Usa resposta direta padrão
        if len(text_lower.split()) <= 4 and not any(kw in text_lower for kw in ["pesquise", "busque", "analise"]):
            return getattr(TaskType, 'DEFAULT', default_type)
        return default_type

    def _create_step(self, name: str, objective: str, description: str, 
                     agent: AgentRole, order: int, base_input: dict, 
                     context: dict, depends_on: list[str] = None) -> Step:
        return Step(
            name=name,
            objective=objective,
            description=description,
            assigned_agent=agent,
            order=order,
            input_data=base_input.copy(),
            context=context.copy(),
            depends_on=depends_on or []
        )

    def _plan_math_direct(self, workflow: Workflow, expr: str, base_input: dict, context: dict):
        """Plano de execução ultrarrápido para cálculos matemáticos."""
        try:
            resultado = eval(expr)
            output_str = f"Resultado do cálculo: {expr} = {resultado}"
        except Exception:
            output_str = f"Execução de cálculo para: {expr}"

        s1 = self._create_step(
            name="Cálculo Direto",
            objective=f"Resolver a expressão matemática: {expr}",
            description=output_str,
            agent=getattr(AgentRole, 'LOGOS', AgentRole.SOPHIA),
            order=1,
            base_input=base_input,
            context=context
        )
        workflow.add_step(s1)

    def _plan_research(self, workflow: Workflow, user_text: str, base_input: dict, context: dict):
        """Planeja a estratégia de pesquisa injetando o tema real do usuário."""
        s1 = self._create_step(
            name="Coleta de Fontes",
            objective=f"Pesquisar e catalogar dados brutos sobre: '{user_text}'",
            description=f"Buscar na memória e base documental dados iniciais sobre '{user_text}'.",
            agent=AgentRole.JUSTITIA,
            order=1,
            base_input=base_input,
            context=context
        )
        s2 = self._create_step(
            name="Análise Cognitiva",
            objective=f"Correlacionar e extrair insights sobre: '{user_text}'",
            description=f"Processar as fontes brutas e analisar o tema '{user_text}'.",
            agent=AgentRole.SOPHIA,
            order=2,
            base_input=base_input,
            context=context,
            depends_on=[s1.id]
        )
        s3 = self._create_step(
            name="Revisão Crítica",
            objective=f"Garantir a veracidade do relatório sobre: '{user_text}'",
            description=f"Avaliar se os insights respondem à demanda '{user_text}' sem alucinações.",
            agent=AgentRole.CRITIAS,
            order=3,
            base_input=base_input,
            context=context,
            depends_on=[s2.id]
        )
        workflow.add_step(s1)
        workflow.add_step(s2)
        workflow.add_step(s3)

    def _plan_summary(self, workflow: Workflow, user_text: str, base_input: dict, context: dict):
        s1 = self._create_step(
            name="Extração de Tópicos",
            objective=f"Identificar os pontos-chave de: '{user_text}'",
            description=f"Analisar o conteúdo relativo a '{user_text}' e mapear a estrutura.",
            agent=AgentRole.SOPHIA,
            order=1,
            base_input=base_input,
            context=context
        )
        s2 = self._create_step(
            name="Redação do Resumo",
            objective=f"Escrever resumo coeso sobre: '{user_text}'",
            description=f"Consolidar os tópicos em uma narrativa clara para '{user_text}'.",
            agent=getattr(AgentRole, 'MUSA', AgentRole.SOPHIA),
            order=2,
            base_input=base_input,
            context=context,
            depends_on=[s1.id]
        )
        workflow.add_step(s1)
        workflow.add_step(s2)

    def _plan_coding(self, workflow: Workflow, user_text: str, base_input: dict, context: dict):
        s1 = self._create_step(
            name="Arquitetura e Lógica",
            objective=f"Desenhar e codificar a solução para: '{user_text}'",
            description=f"Escrever o código-fonte limpo para atender: '{user_text}'.",
            agent=getattr(AgentRole, 'LOGOS', AgentRole.SOPHIA),
            order=1,
            base_input=base_input,
            context=context
        )
        s2 = self._create_step(
            name="Revisão de Código",
            objective=f"Validar a segurança e performance do código de: '{user_text}'",
            description=f"Revisar o código gerado procurando por erros ou vulnerabilidades.",
            agent=AgentRole.CRITIAS,
            order=2,
            base_input=base_input,
            context=context,
            depends_on=[s1.id]
        )
        workflow.add_step(s1)
        workflow.add_step(s2)

    def _plan_default(self, workflow: Workflow, user_text: str, base_input: dict, context: dict):
        s1 = self._create_step(
            name="Atendimento Direto",
            objective=f"Processar consulta do usuário: '{user_text}'",
            description=f"Resposta direta para a solicitação: '{user_text}'",
            agent=AgentRole.SOPHIA,
            order=1,
            base_input=base_input,
            context=context
        )
        workflow.add_step(s1)