import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional, Dict, Any

try:
    import anthropic
except ImportError:
    anthropic = None


class LLMAdapterError(Exception):
    """Exceção customizada para erros de comunicação ou configuração nos Adapters de LLM."""
    pass


@dataclass
class LLMResponse:
    """Estrutura imutável de resposta padronizada retornada pelos Adapters de LLM."""
    text: str
    model: str
    tokens_used: int = 0


class LLMAdapter(ABC):
    """Interface base para todos os provedores de modelos de linguagem (LLM)."""

    @abstractmethod
    def generate(self, system_prompt: str, user_prompt: str, **kwargs) -> LLMResponse:
        """Gera uma resposta padronizada (LLMResponse) a partir do system_prompt e user_prompt."""
        pass


class MockLLMAdapter(LLMAdapter):
    """Adapter de teste offline que simula respostas determinísticas mantendo o contrato LLMResponse."""

    def generate(self, system_prompt: str, user_prompt: str, **kwargs) -> LLMResponse:
        sys_p = (system_prompt or "").lower()
        usr_p = (user_prompt or "").lower()
        
        model_used = "mock-llm-v1"

        if "justitia" in sys_p or "legal" in sys_p or "compliance" in usr_p:
            text = "Análise Legal (Mock): O procedimento atende aos requisitos de conformidade e marcos normativos aplicáveis."
        elif "tech" in sys_p or "vulnerabilidade" in usr_p or "segurança" in usr_p:
            text = "Análise Técnica (Mock): Nenhuma vulnerabilidade crítica de injeção ou autorização detectada nos módulos avaliados."
        elif "sophia" in sys_p or "literary" in sys_p:
            text = "Análise de Linguagem (Mock): A estrutura textual apresenta coerência conceitual, rigor técnico e clareza de exposição."
        elif "critias" in sys_p or "auditor" in sys_p:
            text = "Revisão Crítica (Mock): Parecer aprovado sem objeções ou desalinhamentos operacionais detectados."
        else:
            text = f"Resposta Mock Genérica para o objetivo: '{user_prompt[:50]}...'"

        return LLMResponse(text=text, model=model_used, tokens_used=42)


class AnthropicAdapter(LLMAdapter):
    """Adapter para chamadas reais à API da Anthropic (Claude), respeitando o contrato LLMResponse."""

    def __init__(
        self, 
        model: str = "claude-3-5-sonnet-latest", 
        api_key: Optional[str] = None, 
        timeout: float = 30.0
    ):
        self.model = model
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        self.timeout = timeout

        if not self.api_key:
            raise LLMAdapterError("ANTHROPIC_API_KEY não foi encontrada no ambiente.")

        if anthropic is None:
            raise LLMAdapterError("A biblioteca 'anthropic' não está instalada. Rode: pip install anthropic")

        try:
            # Passa o timeout e a API key para o SDK da Anthropic
            self.client = anthropic.Anthropic(api_key=self.api_key, timeout=self.timeout)
        except Exception as e:
            raise LLMAdapterError(f"Falha ao inicializar o cliente Anthropic: {str(e)}")

    def generate(self, system_prompt: str, user_prompt: str, **kwargs) -> LLMResponse:
        try:
            request_params = {
                "model": self.model,
                "max_tokens": kwargs.get("max_tokens", 1024),
                "messages": [{"role": "user", "content": user_prompt}]
            }
            if system_prompt:
                request_params["system"] = system_prompt

            response = self.client.messages.create(**request_params)
            
            out_text = ""
            if response.content and len(response.content) > 0:
                out_text = response.content[0].text

            tokens_used = 0
            if hasattr(response, "usage") and response.usage:
                tokens_used = getattr(response.usage, "output_tokens", 0) + getattr(response.usage, "input_tokens", 0)

            return LLMResponse(
                text=out_text,
                model=self.model,
                tokens_used=tokens_used
            )

        except Exception as e:
            raise LLMAdapterError(f"Falha ao gerar resposta via {self.model}: {str(e)}")