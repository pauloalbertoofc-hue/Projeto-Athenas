from athena.domain.memory.working_memory import WorkingMemory
from athena.domain.memory.episodic_memory import EpisodicMemory
from athena.domain.memory.semantic_memory import SemanticMemory

class Memory:
    """Fachada unificada da Memória Cognitiva da Athena."""
    def __init__(self):
        self.working = WorkingMemory()
        self.episodic = EpisodicMemory()
        self.semantic = SemanticMemory()

    def remember(self, key: str, artifact: any) -> None:
        self.working.set(key, artifact)

    def recall(self, key: str) -> any:
        return self.working.get(key)