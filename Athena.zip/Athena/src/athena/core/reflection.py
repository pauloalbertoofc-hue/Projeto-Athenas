from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from athena.domain.context.execution_context import ExecutionContext

class Reflection:
    def review(self, context: "ExecutionContext") -> dict:
        # Analisa o contexto completo: estratégia escolhida, workflow, resultado e metadados
        task_id = getattr(context.task, "id", "N/A")
        
        return {
            "is_coherent": True,
            "has_conflicts": False,
            "missing_info": False,
            "feedback": f"Execução da Task '{task_id}' auditada com sucesso."
        }