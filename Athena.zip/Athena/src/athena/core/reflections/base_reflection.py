from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from athena.domain.context.execution_context import ExecutionContext

class Reflection(ABC):
    """Contrato abstrato para auditores e avaliadores de coerência do Kernel."""

    @abstractmethod
    def review(self, context: "ExecutionContext") -> dict:
        pass