from athena.core.reflections.base_reflection import Reflection
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from athena.domain.context.execution_context import ExecutionContext

class BasicReflection(Reflection):
    """Implementação base e síncrona de validação de coerência."""

    def review(self, context: "ExecutionContext") -> dict:
        task_id = getattr(context.task, "id", "N/A")
        return {
            "is_coherent": True,
            "has_conflicts": False,
            "missing_info": False,
            "feedback": f"Execução da Task '{task_id}' auditada sem conflitos."
        }