from typing import Dict, List, Optional
from athena.domain.task import Task
from athena.domain.context.execution_context import ExecutionContext
from athena.domain.context.execution_status import ExecutionStatus
from athena.core.executive_core import ExecutiveCore

class ExecutiveController:
    """
    Tabela de Processos e Gerenciador de Ciclo de Vida do Kernel.
    Mapeia execution_id -> ExecutionContext (PCB) e oferece operações de controle.
    """
    def __init__(self, core: ExecutiveCore):
        self.core = core
        self._executions: Dict[str, ExecutionContext] = {}

    def submit(self, task: Task, parent_execution_id: Optional[str] = None) -> ExecutionContext:
        """Dispara uma nova execução no ExecutiveCore e a registra na Tabela de Processos."""
        context = self.core.execute(task, parent_execution_id=parent_execution_id)
        self._executions[context.execution_id] = context
        return context

    def get_execution(self, execution_id: str) -> Optional[ExecutionContext]:
        """Busca o PCB de uma execução pelo ID."""
        return self._executions.get(execution_id)

    def list_running(self) -> List[ExecutionContext]:
        """Filtra todas as execuções em andamento (PLANNED ou RUNNING)."""
        return [
            ctx for ctx in self._executions.values()
            if ctx.status in (ExecutionStatus.PLANNED, ExecutionStatus.RUNNING)
        ]

    def list_all(self) -> List[ExecutionContext]:
        """Retorna o histórico completo de execuções mantidas em memória."""
        return list(self._executions.values())

    def cancel(self, execution_id: str, reason: str = "Cancelado pelo usuário") -> bool:
        """Interrompe a execução e atualiza o estado do PCB para CANCELLED."""
        context = self.get_execution(execution_id)
        if context and context.status in (ExecutionStatus.CREATED, ExecutionStatus.PLANNED, ExecutionStatus.RUNNING):
            context.status = ExecutionStatus.CANCELLED
            context.metadata.extra["cancellation_reason"] = reason
            context.touch()
            return True
        return False