from __future__ import annotations
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from athena.domain.task import Task
    from athena.domain.planning.planning_result import PlanningResult

class Planner(ABC):
    """Contrato abstrato para motores de planejamento da Athena."""

    @abstractmethod
    def plan(self, task: Task) -> PlanningResult:
        """Transforma uma Task em um PlanningResult (Ordem de Missão)."""
        pass