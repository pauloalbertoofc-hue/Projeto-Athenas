import re
from athena.core.planners.base_planner import Planner
from athena.domain.task import Task
from athena.domain.planning.planning_result import PlanningResult
from athena.domain.planning.strategy import Strategy
from athena.domain.planning.complexity import Complexity
from athena.domain.planning.priority import Priority
from athena.domain.planning.execution_mode import ExecutionMode
from athena.domain.cognitve_process import CognitiveProcess


class RulePlanner(Planner):
    """
    Planejador baseado em regras heurísticas dinâmicas.
    Inspeciona a Task e decide a estratégia, complexidade e processos necessários.
    """

    def plan(self, task: Task) -> PlanningResult:
        # Extrai o texto da missão a partir da descrição ou do título
        raw_text = (getattr(task, 'description', '') or getattr(task, 'title', '') or '').strip()
        text_lower = raw_text.lower()

        # -------------------------------------------------------------------
        # REGRA 1: Expressões Matemáticas ou Cálculos Diretos (ex: "2+2", "10*5")
        # -------------------------------------------------------------------
        if self._is_math_expression(raw_text):
            return PlanningResult(
                strategy=getattr(Strategy, 'DIRECT_ANSWER', Strategy.DEFAULT),
                complexity=Complexity.LOW,
                priority=Priority.NORMAL,
                execution_mode=ExecutionMode.SEQUENTIAL,
                confidence=1.0,
                reasoning="Cálculo matemático direto detectado. Resposta imediata sem necessidade de pesquisa.",
                estimated_steps=1,
                required_processes=[CognitiveProcess.ANALYSIS],
                requires_memory=False,
                requires_reflection=False,
                estimated_compute_cost=0.1,
                estimated_duration_seconds=0.1
            )

        # -------------------------------------------------------------------
        # REGRA 2: Consultas do Domínio Jurídico (ex: "artigo 121", "petição", "réu")
        # -------------------------------------------------------------------
        legal_keywords = ["direito", "lei", "artigo", "código", "cf", "penal", "processo", "petição", "réu", "juiz", "jurisprudência"]
        if any(kw in text_lower for kw in legal_keywords):
            return PlanningResult(
                strategy=getattr(Strategy, 'LEGAL_ANALYSIS', Strategy.DEFAULT),
                complexity=Complexity.HIGH if len(raw_text) > 60 else Complexity.MEDIUM,
                priority=Priority.HIGH,
                execution_mode=ExecutionMode.SEQUENTIAL,
                confidence=0.95,
                reasoning="Demanda do domínio jurídico identificada. Ativando busca em memória e validação formal.",
                estimated_steps=3,
                required_processes=[CognitiveProcess.ANALYSIS, CognitiveProcess.VALIDATION],
                requires_memory=True,
                requires_reflection=True,
                estimated_compute_cost=1.5,
                estimated_duration_seconds=1.0
            )

        # -------------------------------------------------------------------
        # REGRA 3: Perguntas Curtas ou Conceituais do Kernel (ex: "o que é kernel?", "athena?")
        # -------------------------------------------------------------------
        if len(text_lower.split()) <= 4 or "kernel" in text_lower or "athena" in text_lower:
            return PlanningResult(
                strategy=getattr(Strategy, 'DIRECT_ANSWER', Strategy.DEFAULT),
                complexity=Complexity.LOW,
                priority=Priority.NORMAL,
                execution_mode=ExecutionMode.SEQUENTIAL,
                confidence=0.9,
                reasoning="Consulta direta/conceitual curta. Resposta objetiva de baixa complexidade.",
                estimated_steps=1,
                required_processes=[CognitiveProcess.ANALYSIS],
                requires_memory=True,
                requires_reflection=False,
                estimated_compute_cost=0.3,
                estimated_duration_seconds=0.3
            )

        # -------------------------------------------------------------------
        # REGRA 4: Fallback / Pesquisa Geral
        # -------------------------------------------------------------------
        return PlanningResult(
            strategy=Strategy.DEFAULT,
            complexity=Complexity.MEDIUM,
            priority=Priority.NORMAL,
            execution_mode=ExecutionMode.SEQUENTIAL,
            confidence=0.85,
            reasoning="Análise base por regras concluída. Aplicando fluxo padrão de pesquisa.",
            estimated_steps=2,
            required_processes=[CognitiveProcess.ANALYSIS, CognitiveProcess.VALIDATION],
            requires_memory=True,
            requires_reflection=True,
            estimated_compute_cost=1.0,
            estimated_duration_seconds=0.5
        )

    def _is_math_expression(self, text: str) -> bool:
        """Verifica se o texto é uma expressão aritmética direta (ex: 2+2, 100 / 4)."""
        clean = text.replace(" ", "")
        # Checa se contém apenas números e operadores matemáticos
        has_math_chars = bool(re.match(r"^[\d\.\+\-\*\/\(\)\%\^]+$", clean))
        has_operator = any(op in clean for op in "+-*/%^")
        return has_math_chars and has_operator