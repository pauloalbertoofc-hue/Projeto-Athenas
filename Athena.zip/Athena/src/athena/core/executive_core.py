from typing import Optional, Any
from athena.domain.context.execution_context import ExecutionContext
from athena.memory.core.dtos import MemoryRecord, MemoryDomain, MemoryPolicy, PrivacyLevel


class ExecutiveCore:
    """
    O Maestro do Executive System no COS Athena.
    Gerencia o ciclo de vida da missão via PCB (ExecutionContext)
    e orquestra Planner, Workflow, Executor, Reflection e o MOS.
    """

    def __init__(
        self, 
        planner: Any, 
        memory: Any, 
        router: Any, 
        workflow_builder: Any, 
        workflow_executor: Any, 
        reflection: Any
    ):
        self.planner = planner
        self.memory = memory  # Instância do MOS (MemoryManager)
        self.router = router
        self.workflow_builder = workflow_builder
        self.workflow_executor = workflow_executor
        self.reflection = reflection

    def execute(self, task: Any, parent_execution_id: str = None) -> ExecutionContext:
        # 1. Instancia o PCB (ExecutionContext)
        context = ExecutionContext(task=task, parent_execution_id=parent_execution_id)

        try:
            # 2. Transição para PLANNED (Invocação correta do método .plan)
            if hasattr(self.planner, 'plan'):
                planning_result = self.planner.plan(context.task)
            elif hasattr(self.planner, 'choose_strategy'):
                planning_result = self.planner.choose_strategy(context.task)
            else:
                planning_result = None

            # Extrai o objeto Strategy se for um PlanningResult completo
            strategy = getattr(planning_result, 'strategy', planning_result)
            if hasattr(context, 'set_strategy'):
                context.set_strategy(strategy)

            # 3. Transição para RUNNING (Construção do Workflow)
            workflow = self.workflow_builder.build(context.task)
            if hasattr(context, 'set_workflow'):
                context.set_workflow(workflow)

            # 4. Execução do fluxo de trabalho pelos Especialistas
            result = self.workflow_executor.execute(context.workflow)
            if hasattr(context, 'set_result'):
                context.set_result(result)

            # 5. Auditoria e Reflexão Crítica
            audit = self.reflection.review(context)
            if hasattr(context, 'set_audit'):
                context.set_audit(audit)

        except Exception as e:
            # Tratamento de erro integrado ao PCB
            error_payload = {"message": str(e), "type": type(e).__name__}
            if hasattr(context, 'set_failed'):
                context.set_failed(error_payload)
            print(f"[EXECUTIVE CORE ERROR] 🚨 Falha na execução do PCB: {e}")

        # 6. Persistência na Memória Cognitiva
        self._persist_in_memory(context)

        return context

    def _persist_in_memory(self, context: ExecutionContext):
        """Grava a execução do PCB diretamente no MOS (Persistência em Disco)."""
        try:
            if hasattr(self.memory, 'save'):
                exec_id = getattr(context, 'execution_id', 'exec_001')
                record = MemoryRecord(
                    content={
                        "execution_id": exec_id,
                        "task_title": getattr(context.task, 'title', ''),
                        "status": getattr(context, 'status', 'COMPLETED'),
                        "result": str(getattr(context, 'result', ''))
                    },
                    domain=MemoryDomain.GENERAL,
                    metadata={
                        "execution_id": exec_id,
                        "task_id": getattr(context.task, 'id', '')
                    },
                    policy=MemoryPolicy(privacy=PrivacyLevel.INTERNAL, confidence_score=0.95)
                )
                self.memory.save(record)
            elif hasattr(self.memory, 'remember'):
                exec_id = getattr(context, 'execution_id', 'exec_001')
                self.memory.remember("execution.current", context)
                self.memory.remember(f"execution.{exec_id}", context)
        except Exception as e:
            print(f"[EXECUTIVE MEMORY WARNING] ⚠️ Não foi possível salvar o PCB no MOS: {e}")