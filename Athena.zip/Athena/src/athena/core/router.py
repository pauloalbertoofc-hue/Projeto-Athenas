from typing import List, TYPE_CHECKING
from athena.domain.cognitve_process import CognitiveProcess

if TYPE_CHECKING:
    from athena.agents_ofc.base_agent import Specialist
    from athena.core.registry import SpecialistRegistry

class Router:
    """Despachante puro que consulta o Registry sem mapas estáticos."""

    def __init__(self, registry: "SpecialistRegistry"):
        self.registry = registry

    def resolve_process(self, process: CognitiveProcess) -> List["Specialist"]:
        return self.registry.get_instances_by_process(process)