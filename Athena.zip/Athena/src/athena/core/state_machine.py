from datetime import datetime
from athena.domain.step import Step, StepStatus

class StateMachine:
    """
    Governa puramente as transições de estado de um Step.
    Livre de efeitos colaterais como prints ou IO.
    """

    def start(self, step: Step):
        if step.status != StepStatus.PENDING:
            raise ValueError(f"Transição inválida: {step.status.value} -> RUNNING")
        step.status = StepStatus.RUNNING
        step.started_at = datetime.utcnow()
        step._touch()

    def complete(self, step: Step, output_data: dict):
        if step.status != StepStatus.RUNNING:
            raise ValueError(f"Transição inválida: {step.status.value} -> COMPLETED")
        step.output_data = output_data
        step.status = StepStatus.COMPLETED
        step.completed_at = datetime.utcnow()
        step._touch()

    def fail(self, step: Step) -> bool:
        """Registra a falha. Retorna True se o passo puder tentar novamente (Retry)."""
        step.current_retry += 1
        step._touch()
        
        if step.can_retry:
            step.status = StepStatus.PENDING
            return True
        else:
            step.status = StepStatus.FAILED
            step.completed_at = datetime.utcnow()
            return False

    def skip(self, step: Step):
        """Pula um passo que se tornou desnecessário dinamicamente."""
        step.status = StepStatus.SKIPPED
        step.completed_at = datetime.utcnow()
        step._touch()

    def cancel(self, step: Step):
        """Cancela a execução por ordem superior."""
        step.status = StepStatus.FAILED
        step.completed_at = datetime.utcnow()
        step._touch()