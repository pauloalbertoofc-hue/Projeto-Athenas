from typing import Dict, List, Type, TYPE_CHECKING
from athena.domain.cognitve_process import CognitiveProcess

if TYPE_CHECKING:
    from athena.agents_ofc.base_agent import Specialist

class SpecialistRegistry:
    """Catálogo indexado dinamicamente pelas capacidades e processos declarados pelos agentes."""

    def __init__(self):
        self._process_registry: Dict[CognitiveProcess, List[Type["Specialist"]]] = {}

    def register(self, specialist_cls: Type["Specialist"]) -> None:
        processes = getattr(specialist_cls, "processes", [])
        for process in processes:
            if process not in self._process_registry:
                self._process_registry[process] = []
            if specialist_cls not in self._process_registry[process]:
                self._process_registry[process].append(specialist_cls)

    def get_instances_by_process(self, process: CognitiveProcess) -> List["Specialist"]:
        """Retorna instâncias zeradas e isoladas dos especialistas registrados para o processo."""
        classes = self._process_registry.get(process, [])
        return [cls() for cls in classes]