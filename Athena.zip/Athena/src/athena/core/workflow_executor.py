from datetime import datetime
from typing import Optional, Any
from athena.domain.step import Step
from athena.domain.workflow import Workflow, WorkflowStatus
from athena.core.state_machine import StateMachine
from athena.core.agent_runner import MockAgentRunner

class WorkflowExecutor:
    """
    O Orquestrador puro do Kernel.
    Centraliza logs visuais e dita o ritmo da pipeline cognitiva.
    """

    def __init__(self, router: Optional[Any] = None, agent_runner: Optional[Any] = None, state_machine: Optional[StateMachine] = None):
        self.router = router
        self.state_machine = state_machine or StateMachine()
        # Permite injetar um Runner por fora ou usar o MockAgentRunner padrão
        self.agent_runner = agent_runner or MockAgentRunner()

    def execute(self, workflow: Workflow) -> Workflow:
        print(f"\n[EXECUTION START] 🎬 Iniciando orquestração: {workflow.name}")
        workflow.status = WorkflowStatus.ACTIVE
        workflow.updated_at = datetime.utcnow()

        while True:
            step = workflow.next_executable_step()
            if not step:
                break
                
            self._process_step(step)

        # Avaliação do status macro do plano
        if workflow.has_failed_step:
            workflow.status = WorkflowStatus.FAILED
            print(f"\n[EXECUTION FAILED] ❌ O Workflow '{workflow.name}' faliu criticamente.")
        elif workflow.is_complete:
            workflow.status = WorkflowStatus.COMPLETED
            print(f"\n[EXECUTION SUCCESS] 🎉 O Workflow '{workflow.name}' foi concluído com sucesso!")
            
        workflow.updated_at = datetime.utcnow()
        return workflow

    def _process_step(self, step: Step):
        """Orquestra o ciclo de vida do passo com tipagem forte e logs centralizados."""
        print(f"\n  [ORCHESTRATOR] 🎯 Executando: '{step.name}' (Ordem {step.order})")
        
        # Transição de estado
        self.state_machine.start(step)
        print(f"    [STATE] ⏳ Status alterado para: RUNNING")

        try:
            agent_name = step.assigned_agent.value.upper() if hasattr(step.assigned_agent, 'value') else str(step.assigned_agent)
            print(f"    [AGENT] 🚀 Despachando para a mente do especialista [{agent_name}]...")
            
            # Executa usando o agent_runner já configurado
            output = self.agent_runner.run(step)
            
            self.state_machine.complete(step, output_data=output)
            print(f"    [STATE] ✅ Status alterado para: COMPLETED")
            
        except Exception as e:
            should_retry = self.state_machine.fail(step)
            if should_retry:
                current = getattr(step, 'current_retry', 1)
                max_r = getattr(step, 'max_retries', 3)
                print(f"    [STATE] ⚠️ Falha detectada! Tentativa {current}/{max_r}. Retornando à fila.")
            else:
                print(f"    [STATE] 🚨 Limite de retries esgotado. Passo marcado como FAILED.")