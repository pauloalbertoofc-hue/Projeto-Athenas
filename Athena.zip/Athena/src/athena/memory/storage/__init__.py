"""
Módulo do Armazenamento Físico da Memória (Storage Layer)
"""