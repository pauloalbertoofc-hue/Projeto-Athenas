"""
Módulo de Serviços de Conhecimento, Grafos e Redes Conceituais
"""