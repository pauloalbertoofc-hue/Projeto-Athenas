"""
MOS - Memory Operating System da Athena
"""