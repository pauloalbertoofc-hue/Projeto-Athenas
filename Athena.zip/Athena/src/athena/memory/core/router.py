from athena.memory.core.contracts import IMemoryRouter
from athena.memory.core.dtos import MemoryRecord, MemoryDomain, PrivacyLevel


class MemoryRouter(IMemoryRouter):
    """Roteador Multicritério: Domínio + Prioridade + Políticas de Governança."""

    def route(self, record: MemoryRecord) -> str:
        # Se for um rascunho de baixa confiança, vai para a Working Memory
        if record.policy.confidence_score < 0.5:
            return "storage/working"

        # Se for dados confidenciais sensíveis, vai para área protegida da Pessoal
        if record.policy.privacy == PrivacyLevel.CONFIDENTIAL and record.domain == MemoryDomain.PERSONAL:
            return "libraries/personal/vault"

        # Mapeamento por Domínio
        domain_map = {
            MemoryDomain.LEGAL: "libraries/legal",
            MemoryDomain.LITERARY: "libraries/literary",
            MemoryDomain.TECHNICAL: "libraries/technical",
            MemoryDomain.SCIENTIFIC: "libraries/scientific",
            MemoryDomain.PERSONAL: "libraries/personal",
            MemoryDomain.GENERAL: "storage/long_term",
        }
        return domain_map.get(record.domain, "storage/long_term")