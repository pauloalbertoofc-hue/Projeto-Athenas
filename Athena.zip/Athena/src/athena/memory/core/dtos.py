from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, Optional


class PrivacyLevel(Enum):
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"


class MemoryDomain(Enum):
    GENERAL = "general"
    LEGAL = "legal"
    LITERARY = "literary"
    TECHNICAL = "technical"
    SCIENTIFIC = "scientific"
    PERSONAL = "personal"


class TaskPriority(Enum):
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class MemoryPolicy:
    """Regras de governança, permissão e retenção atribuídas à memória."""
    privacy: PrivacyLevel = PrivacyLevel.INTERNAL
    confidence_score: float = 1.0
    allow_export: bool = True
    retention_days: int = -1  # -1 indica retenção permanente


@dataclass
class MemoryRecord:
    """Unidade mínima de conhecimento capturada (Dado bruto de entrada)."""
    content: Any
    domain: MemoryDomain = MemoryDomain.GENERAL
    metadata: Dict[str, Any] = field(default_factory=dict)
    policy: MemoryPolicy = field(default_factory=MemoryPolicy)


@dataclass
class MemoryEntry:
    """Registro imutável já processado, indexado e persistido no armazenamento."""
    id: str
    content: Any
    domain: MemoryDomain
    created_at: datetime
    metadata: Dict[str, Any]
    policy: MemoryPolicy
    version: int = 1


@dataclass
class MemoryQuery:
    """Objeto de transporte para solicitar buscas no MOS."""
    query_text: str
    domain: Optional[MemoryDomain] = None
    limit: int = 10
    filters: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MemoryTask:
    """Fila de tarefas assíncronas gerenciadas pelo Scheduler."""
    id: str
    task_type: str
    priority: TaskPriority
    scheduled_at: datetime
    callback: Callable[..., Any]
    payload: Dict[str, Any] = field(default_factory=dict)