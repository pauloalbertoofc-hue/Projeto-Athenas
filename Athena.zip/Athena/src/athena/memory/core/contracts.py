from abc import ABC, abstractmethod
from typing import Callable, List, Optional
from athena.memory.core.dtos import MemoryRecord, MemoryEntry, MemoryQuery, MemoryTask
from athena.memory.core.events import MemoryEvent, MemoryEventType


class IMemoryRouter(ABC):
    @abstractmethod
    def route(self, record: MemoryRecord) -> str:
        """Determina o caminho de armazenamento com base em múltiplos critérios."""
        pass


class IStorageEngine(ABC):
    @abstractmethod
    def save(self, entry: MemoryEntry, location: str) -> bool:
        """Persiste fisicamente o registro no destino."""
        pass

    @abstractmethod
    def read(self, entry_id: str, location: str) -> Optional[MemoryEntry]:
        """Lê fisicamente um registro do destino."""
        pass

    @abstractmethod
    def archive(self, entry_id: str, location: str) -> bool:
        """Move o registro para o arquivo histórico."""
        pass


class IMemoryIndex(ABC):
    @abstractmethod
    def index_entry(self, entry: MemoryEntry, storage_location: str) -> None:
        """Guarda a localização física/lógica do registro."""
        pass

    @abstractmethod
    def locate(self, entry_id: str) -> Optional[str]:
        """Mapeia o endereço de um registro pelo ID."""
        pass


class IMemoryCache(ABC):
    @abstractmethod
    def get(self, key: str) -> Optional[MemoryEntry]:
        pass

    @abstractmethod
    def set(self, key: str, entry: MemoryEntry, ttl_seconds: int = 300) -> None:
        pass


class IEventBus(ABC):
    @abstractmethod
    def publish(self, event: MemoryEvent) -> None:
        pass

    @abstractmethod
    def subscribe(self, event_type: MemoryEventType, callback: Callable[[MemoryEvent], None]) -> None:
        pass


class IMemoryManager(ABC):
    @abstractmethod
    def save(self, record: MemoryRecord) -> MemoryEntry:
        """Orquestra a gravação de memórias no Kernel."""
        pass

    @abstractmethod
    def search(self, query: MemoryQuery) -> List[MemoryEntry]:
        """Orquestra a consulta de memórias no Kernel."""
        pass