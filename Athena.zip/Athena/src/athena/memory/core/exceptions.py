class MOSException(Exception):
    """Exceção base de onde derivam todos os erros do MOS."""
    pass


class MemoryNotFoundException(MOSException):
    """Lançada quando um registro ou localização de memória não é encontrada."""
    pass


class GovernanceViolationException(MOSException):
    """Lançada quando uma gravação, leitura ou exportação viola as regras de governança."""
    pass


class StorageWriteException(MOSException):
    """Lançada em falhas físicas de gravação no armazenamento de memória."""
    pass