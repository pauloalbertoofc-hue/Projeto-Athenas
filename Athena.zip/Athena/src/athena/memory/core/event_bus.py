from typing import Callable, Dict, List
from athena.memory.core.contracts import IEventBus
from athena.memory.core.events import MemoryEvent, MemoryEventType


class EventBus(IEventBus):
    """Barramento de Eventos Pub/Sub desacoplado do MOS."""

    def __init__(self):
        self._subscribers: Dict[MemoryEventType, List[Callable[[MemoryEvent], None]]] = {}

    def subscribe(self, event_type: MemoryEventType, callback: Callable[[MemoryEvent], None]) -> None:
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        self._subscribers[event_type].append(callback)

    def publish(self, event: MemoryEvent) -> None:
        if event.event_type in self._subscribers:
            for callback in self._subscribers[event.event_type]:
                try:
                    callback(event)
                except Exception as e:
                    print(f"[EVENT BUS ERROR] Falha ao processar suscritor para {event.event_type.value}: {e}")