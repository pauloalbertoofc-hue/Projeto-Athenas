from typing import Dict, List, Optional
from athena.memory.core.contracts import IMemoryIndex
from athena.memory.core.dtos import MemoryEntry, MemoryDomain


class MemoryIndex(IMemoryIndex):
    """GPS do MOS: Mantém o catálogo de endereços com suporte a reconstrução no Boot."""

    def __init__(self):
        self._catalog: Dict[str, str] = {}
        self._domain_map: Dict[MemoryDomain, List[str]] = {}

    def index_entry(self, entry: MemoryEntry, storage_location: str, verbose: bool = True) -> None:
        self._catalog[entry.id] = storage_location
        if entry.domain not in self._domain_map:
            self._domain_map[entry.domain] = []
        if entry.id not in self._domain_map[entry.domain]:
            self._domain_map[entry.domain].append(entry.id)

        if verbose:
            print(f"[INDEX GPS] 🗺️ Registrado ponteiro: '{entry.id}' -> '{storage_location}'")

    def locate(self, entry_id: str) -> Optional[str]:
        return self._catalog.get(entry_id)

    def list_by_domain(self, domain: Optional[MemoryDomain]) -> List[str]:
        if domain and domain in self._domain_map:
            return self._domain_map[domain]
        return list(self._catalog.keys())

    def rebuild_from_storage(self, storage_engine) -> int:
        """Reconstrói o índice completo em RAM varrendo os arquivos salvos em disco."""
        scanned_items = storage_engine.scan_all_entries()
        for entry, location in scanned_items:
            self.index_entry(entry, location, verbose=False)
        
        count = len(scanned_items)
        if count > 0:
            print(f"[INDEX GPS] 🔄 Reconstrução concluída! {count} registros reindexados a partir do disco.")
        return count