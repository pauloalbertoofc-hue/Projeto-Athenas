from typing import Dict, Optional
import time
from athena.memory.core.contracts import IMemoryCache
from athena.memory.core.dtos import MemoryEntry


class MemoryCache(IMemoryCache):
    """Aceleração de leitura em memória RAM."""

    def __init__(self):
        self._store: Dict[str, tuple[MemoryEntry, float]] = {}

    def get(self, key: str) -> Optional[MemoryEntry]:
        if key in self._store:
            entry, expires_at = self._store[key]
            if time.time() < expires_at:
                return entry
            del self._store[key]
        return None

    def set(self, key: str, entry: MemoryEntry, ttl_seconds: int = 300) -> None:
        self._store[key] = (entry, time.time() + ttl_seconds)