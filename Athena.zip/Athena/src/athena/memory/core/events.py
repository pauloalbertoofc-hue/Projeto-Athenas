from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict


class MemoryEventType(Enum):
    CREATED = "MemoryCreated"
    UPDATED = "MemoryUpdated"
    DELETED = "MemoryDeleted"
    ARCHIVED = "MemoryArchived"
    CONSOLIDATED = "MemoryConsolidated"
    GOVERNANCE_BLOCKED = "GovernanceBlocked"


@dataclass
class MemoryEvent:
    """Evento disparado pelo MOS notificando alterações no sistema de memória."""
    event_type: MemoryEventType
    entry_id: str
    timestamp: datetime = field(default_factory=datetime.now)
    payload: Dict[str, Any] = field(default_factory=dict)