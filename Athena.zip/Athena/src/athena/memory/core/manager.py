import uuid
from datetime import datetime
from typing import List

from athena.memory.core.contracts import IMemoryManager
from athena.memory.core.dtos import MemoryRecord, MemoryEntry, MemoryQuery, TaskPriority
from athena.memory.core.router import MemoryRouter
from athena.memory.core.storage_engine import StorageEngine
from athena.memory.core.index import MemoryIndex
from athena.memory.core.cache import MemoryCache
from athena.memory.core.event_bus import EventBus
from athena.memory.core.scheduler import MemoryScheduler
from athena.memory.core.consolidation import MemoryConsolidation
from athena.memory.governance.engine import GovernanceEngine
from athena.memory.core.events import MemoryEvent, MemoryEventType


class MemoryManager(IMemoryManager):
    """FACADE RESTRITA DE ORQUESTRAÇÃO DO MOS (Com leitura e escrita funcionais)."""

    def __init__(
        self,
        governance: GovernanceEngine,
        router: MemoryRouter,
        storage_engine: StorageEngine,
        index: MemoryIndex,
        cache: MemoryCache,
        event_bus: EventBus,
        scheduler: MemoryScheduler,
        consolidation: MemoryConsolidation
    ):
        self.governance = governance
        self.router = router
        self.storage_engine = storage_engine
        self.index = index
        self.cache = cache
        self.event_bus = event_bus
        self.scheduler = scheduler
        self.consolidation = consolidation

    def save(self, record: MemoryRecord) -> MemoryEntry:
        # 1. Checagem de Governança
        self.governance.validate_save(record)

        # 2. Roteamento Multicritério
        location = self.router.route(record)

        # 3. Criação da Entrada Imutável
        entry = MemoryEntry(
            id=f"mem_{uuid.uuid4().hex[:8]}",
            content=record.content,
            domain=record.domain,
            created_at=datetime.now(),
            metadata=record.metadata,
            policy=record.policy
        )

        # 4. Gravação Física no Storage Engine (Disco)
        self.storage_engine.save(entry, location)

        # 5. Indexação no GPS
        self.index.index_entry(entry, location)

        # 6. Aquecimento de Cache
        self.cache.set(entry.id, entry)

        # 7. Disparo de Evento Pub/Sub
        event = MemoryEvent(
            event_type=MemoryEventType.CREATED,
            entry_id=entry.id,
            payload={"domain": record.domain.value, "location": location}
        )
        self.event_bus.publish(event)

        # 8. Agendamento Assíncrono no Scheduler
        self.scheduler.enqueue_task(
            task_type="ReindexCatalog",
            priority=TaskPriority.NORMAL,
            callback=lambda payload: print(f"[SCHEDULER CALLBACK] Reindexando catálogo para {payload['id']}"),
            payload={"id": entry.id}
        )

        return entry

    def search(self, query: MemoryQuery) -> List[MemoryEntry]:
        """Busca REAL no MOS: Filtra por domínio, lê do Cache ou resgata do Storage Engine em Disco."""
        # 1. Validação de segurança na busca
        self.governance.validate_search(query)

        print(f"[MOS SEARCH] 🔍 Buscando por '{query.query_text}' no domínio '{query.domain}'...")
        results: List[MemoryEntry] = []

        # 2. Pergunta ao Index quais IDs correspondem a esse domínio
        candidate_ids = self.index.list_by_domain(query.domain)

        for entry_id in candidate_ids:
            # Tenta pegar primeiro do Cache rápido
            entry = self.cache.get(entry_id)

            # Se não estiver no Cache, resgata fisicamente do Disco
            if not entry:
                location = self.index.locate(entry_id)
                if location:
                    entry = self.storage_engine.read(entry_id, location)
                    if entry:
                        self.cache.set(entry.id, entry)  # Reaquece o cache

            # Filtra por texto se houver correspondência
            if entry and (query.query_text.lower() in str(entry.content).lower()):
                results.append(entry)

            if len(results) >= query.limit:
                break

        print(f"[MOS SEARCH] ✅ Busca concluída! {len(results)} registros retornados do disco.")
        return results