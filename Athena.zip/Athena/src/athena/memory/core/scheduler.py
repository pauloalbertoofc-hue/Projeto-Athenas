import uuid
from datetime import datetime
from typing import Callable, List
from athena.memory.core.dtos import MemoryTask, TaskPriority


class MemoryScheduler:
    """O Daemon do MOS: Gerencia a fila de tarefas de manutenção assíncronas."""

    def __init__(self):
        self._task_queue: List[MemoryTask] = []

    def enqueue_task(self, task_type: str, priority: TaskPriority, callback: Callable[..., None], payload: dict) -> str:
        task = MemoryTask(
            id=f"task_{uuid.uuid4().hex[:6]}",
            task_type=task_type,
            priority=priority,
            scheduled_at=datetime.now(),
            callback=callback,
            payload=payload
        )
        self._task_queue.append(task)
        # Ordena a fila pela prioridade da tarefa
        self._task_queue.sort(key=lambda t: t.priority.value, reverse=True)
        print(f"[SCHEDULER DAEMON] ⏱️ Tarefa '{task.task_type}' enfileirada (Prioridade: {task.priority.name}).")
        return task.id

    def process_queue(self) -> int:
        """Processa a fila de tarefas pendentes (Corrigido erro de sintaxe)."""
        processed_count = 0
        while self._task_queue:
            task = self._task_queue.pop(0)
            print(f"[SCHEDULER DAEMON] ⚙️ Executando tarefa assíncrona '{task.id}' [{task.task_type}]...")
            task.callback(task.payload)
            processed_count += 1
        return processed_count