from athena.memory.core.dtos import MemoryEntry


class MemoryConsolidation:
    """Módulo Pós-Reflection: Promove memórias da Working Memory para a Long-Term Memory."""

    def process_post_reflection(self, entry: MemoryEntry) -> bool:
        print(f"[CONSOLIDATION] 🔍 Analisando pós-Reflection para a memória '{entry.id}'...")
        if entry.policy.confidence_score >= 0.8:
            print(f"[CONSOLIDATION] 🟢 Registro '{entry.id}' promovido com sucesso para a Long-Term Memory!")
            return True
        print(f"[CONSOLIDATION] 🟡 Registro '{entry.id}' mantido apenas no contexto de rascunho.")
        return False