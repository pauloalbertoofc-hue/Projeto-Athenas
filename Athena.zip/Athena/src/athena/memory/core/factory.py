from athena.memory.core.cache import MemoryCache
from athena.memory.core.consolidation import MemoryConsolidation
from athena.memory.core.event_bus import EventBus
from athena.memory.core.index import MemoryIndex
from athena.memory.core.manager import MemoryManager
from athena.memory.core.router import MemoryRouter
from athena.memory.core.scheduler import MemoryScheduler
from athena.memory.core.storage_engine import StorageEngine
from athena.memory.governance.engine import GovernanceEngine


class MemoryFactory:
    """Fábrica do MOS: Constrói as dependências e reconstrói o índice do disco no Boot."""

    @staticmethod
    def create_manager() -> MemoryManager:
        governance = GovernanceEngine()
        router = MemoryRouter()
        storage_engine = StorageEngine()
        index = MemoryIndex()
        cache = MemoryCache()
        event_bus = EventBus()
        scheduler = MemoryScheduler()
        consolidation = MemoryConsolidation()

        # 🛠️ RECONSTRUÇÃO DO ÍNDICE NO BOOT (Cura da amnésia pós-restart)
        index.rebuild_from_storage(storage_engine)

        return MemoryManager(
            governance=governance,
            router=router,
            storage_engine=storage_engine,
            index=index,
            cache=cache,
            event_bus=event_bus,
            scheduler=scheduler,
            consolidation=consolidation
        )