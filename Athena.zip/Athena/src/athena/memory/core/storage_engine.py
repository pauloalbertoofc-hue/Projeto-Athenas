import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from athena.memory.core.contracts import IStorageEngine
from athena.memory.core.dtos import MemoryEntry, MemoryDomain, MemoryPolicy, PrivacyLevel
from athena.memory.core.exceptions import StorageWriteException


class StorageEngine(IStorageEngine):
    """Engine de Persistência Física real no Disco (Salva e varre arquivos JSON)."""

    def __init__(self, base_data_dir: str = ".athena_data"):
        self.base_data_dir = base_data_dir
        os.makedirs(self.base_data_dir, exist_ok=True)

    def _get_file_path(self, entry_id: str, location: str) -> str:
        folder_path = os.path.join(self.base_data_dir, location)
        os.makedirs(folder_path, exist_ok=True)
        return os.path.join(folder_path, f"{entry_id}.json")

    def save(self, entry: MemoryEntry, location: str) -> bool:
        try:
            file_path = self._get_file_path(entry.id, location)
            data = {
                "id": entry.id,
                "content": entry.content,
                "domain": entry.domain.value,
                "created_at": entry.created_at.isoformat(),
                "metadata": entry.metadata,
                "version": entry.version,
                "policy": {
                    "privacy": entry.policy.privacy.value,
                    "confidence_score": entry.policy.confidence_score,
                    "allow_export": entry.policy.allow_export,
                    "retention_days": entry.policy.retention_days,
                }
            }
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

            print(f"[STORAGE ENGINE] 💾 Gravação física em disco: '{file_path}'")
            return True
        except Exception as e:
            raise StorageWriteException(f"Erro ao gravar registro em disco: {e}")

    def read(self, entry_id: str, location: str) -> Optional[MemoryEntry]:
        file_path = self._get_file_path(entry_id, location)
        if not os.path.exists(file_path):
            return None

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            return MemoryEntry(
                id=data["id"],
                content=data["content"],
                domain=MemoryDomain(data["domain"]),
                created_at=datetime.fromisoformat(data["created_at"]),
                metadata=data["metadata"],
                version=data.get("version", 1),
                policy=MemoryPolicy(
                    privacy=PrivacyLevel(data["policy"]["privacy"]),
                    confidence_score=data["policy"]["confidence_score"],
                    allow_export=data["policy"]["allow_export"],
                    retention_days=data["policy"]["retention_days"],
                )
            )
        except Exception as e:
            print(f"[STORAGE ENGINE ERROR] Falha ao ler arquivo do disco: {e}")
            return None

    def scan_all_entries(self) -> List[Tuple[MemoryEntry, str]]:
        """Varre recursivamente a pasta de dados e descobre todas as memórias persistidas."""
        entries: List[Tuple[MemoryEntry, str]] = []
        if not os.path.exists(self.base_data_dir):
            return entries

        for root, _, files in os.walk(self.base_data_dir):
            for file in files:
                if file.endswith(".json"):
                    # Extrai a localização relativa da pasta
                    rel_dir = os.path.relpath(root, self.base_data_dir).replace("\\", "/")
                    entry_id = os.path.splitext(file)[0]
                    entry = self.read(entry_id, rel_dir)
                    if entry:
                        entries.append((entry, rel_dir))
        return entries

    def archive(self, entry_id: str, location: str) -> bool:
        entry = self.read(entry_id, location)
        if entry:
            old_path = self._get_file_path(entry_id, location)
            new_path = self._get_file_path(entry_id, "storage/historical")
            os.rename(old_path, new_path)
            print(f"[STORAGE ENGINE] 📦 Registro {entry_id} movido para 'storage/historical'")
            return True
        return False