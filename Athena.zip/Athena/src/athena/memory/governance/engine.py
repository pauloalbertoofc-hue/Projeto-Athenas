from athena.memory.core.dtos import MemoryRecord, MemoryQuery, PrivacyLevel
from athena.memory.core.exceptions import GovernanceViolationException


class GovernanceEngine:
    """O Juiz da Memória: Valida com rigor se uma informação pode ser gravada ou lida."""

    def validate_save(self, record: MemoryRecord) -> None:
        # Rule 1: Bloqueia memórias com Score de Confiança muito baixo
        if record.policy.confidence_score < 0.3:
            raise GovernanceViolationException(
                f"[GOVERNANCE BLOCKED] Score de confiança {record.policy.confidence_score} insuficiente para gravação."
            )

        # Rule 2: Exige flagged de confidencialidade consistente
        if record.policy.privacy == PrivacyLevel.CONFIDENTIAL and record.policy.allow_export:
            print("[GOVERNANCE WARNING] 🛡️ Alerta: Registro confidencial teve a flag de exportação desativada por segurança.")
            record.policy.allow_export = False

    def validate_search(self, query: MemoryQuery) -> None:
        # Rule 3: Validação de segurança em buscas
        if not query.query_text or len(query.query_text.strip()) == 0:
            raise GovernanceViolationException("[GOVERNANCE BLOCKED] Consulta de memória não pode ser vazia.")