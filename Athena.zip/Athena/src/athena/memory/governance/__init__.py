"""
Módulo de Governança, Regras de Privacidade e Segurança
"""