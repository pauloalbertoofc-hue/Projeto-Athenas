"""
Módulo das Bibliotecas Especializadas por Domínio
"""